# FlowStudio DC1 continuous literature review state

Last completed iteration: 2026-07-22 (Asia/Shanghai), v9.

## Current counts

- Source records retrieved: 1,431
- Deduplicated records screened: 1,262
- Duplicates removed: 169
- Focused synthesis set: 97
- Query clusters: 22
- Database-query log entries: 43, plus explicit ACM DL / Google Scholar access-limit rows

## Current deliverable

- `outputs/flowstudio_dc1_prisma_20260722/FlowStudio_DC1_PRISMA_Literature_Review_20260722_v9.xlsx`
- Server mirror: `/root/flowstudio_lit_review_20260722/`

## Strongest current synthesis

1. Intent is enacted and revised in a manipulation-feedback-repair loop; it is not always a fixed latent label that precedes action.
2. DC1 needs a hierarchical intent model and latent 3D reference-frame model.
3. Intent content and commitment strength must be modeled separately.
4. Repair events are high-value supervision but must be diagnosed by cause before memory updates.
5. Memory retrieval changes the prior and can create confirmation bias; retrieve supporting, conflicting, and failed episodes.
6. Authority is a function-specific vector, with slow agent escalation and instantaneous human reclaim.
7. Initiative timing and interaction rhythm are as important as initiative level.
8. Evaluation should prioritize calibration, repair burden, commitment violations, agency, and creative exploration—not top-1 intent accuracy alone.
9. Tutorial, VLM-inferred, creator-recalled, and controlled-task intent labels are different evidence tiers and must retain provenance.
10. VLMs should be treated as weak pre-annotators; rare, uncertain, constraint-sensitive, and authority-relevant episodes require human review.
11. Reliability must be computed per representation layer: temporal boundaries, observable events, categorical intent fields, multi-label constraints, ordinal commitment and latent rationale need different metrics.
12. Low agreement in high-level creative intent may be valid plural interpretation; preserve it as alternatives instead of forcing a single label.
13. Case similarity, reuse utility, explanation value and authority are distinct; retrieval updates an intent prior but never grants execution permission.
14. A useful retrieval set is contrastive: one support, one near miss, one failed/repair case and one alternative-intent case, with an authority-boundary case added for high-risk queries.
15. Retention is governed: confirmed outcomes enter success memory, unresolved episodes remain ambiguity cases, failures retain diagnosed repair causes, and redundant/stale cases are merged or quarantined.
16. Intent belief and authority must remain separate: high confidence about the user's goal does not itself grant permission to select, apply or remember.
17. Authority is a function vector rather than one scalar level; observe, infer, retrieve, generate, select, apply and remember can be authorized independently.
18. Transitions need hysteresis and asymmetric control: Agent escalation is gradual and evidence-based, while undo, counter-drag or tool reclaim immediately removes apply/select authority.
19. The Intent Hypothesis Graph must separate hypotheses about what the user wants from hypotheses about what the user believes about the scene, active tool, and reference frame; the same action can otherwise be misread under a false shared-state assumption.
20. Missing observations are unknown rather than negative evidence. The posterior must retain explicit unknown/other mass so an apparently concentrated distribution under a mismatched candidate model cannot justify stronger authority.
21. Timing, observation order, and partial observability modify evidence likelihoods rather than deterministically defining intent; the runtime graph should preserve alternatives and provenance through commitment and repair.
22. Evidence applicability and study quality must be separated. The v8 decision-utility score ranks relevance for DC1 synthesis but explicitly cannot be interpreted as risk-of-bias, causal strength, or empirical quality.
23. Provisional study-type triage shows the 97-paper synthesis is design/theory heavy (60 design/system, 14 theory/framework, 12 computational, 7 empirical, 4 review); this is adequate for generating an intent representation but insufficient alone for strong effect claims.
24. Forty-eight papers are provisionally direct to 3D cognition/action or intent inference, 35 are enabling evidence, and 14 are background. The next evidence pass should prioritize full-method appraisal of direct empirical and takeover-boundary studies rather than adding volume indiscriminately.
25. Tutorials should establish observable action–goal prototypes and retrieval cases, not serve as the sole latent-intent ground truth. Controlled tasks, natural open-ended creation, and immediate stimulated recall form the necessary external-validity ladder.
26. VLM labor should stop at pre-segmentation, observable evidence extraction, Top-k hypotheses, counterevidence, and review prioritization. Human/participant evidence remains authoritative for high-level goals, preserve constraints, commitment, repair cause, and takeover boundaries.
27. DC1 should be evaluated as an incremental mechanism ladder (object/geometry → temporal history → goal hierarchy → user belief/frame → typed memory → commitment/repair → authority policy), because a single action-only versus full-system comparison cannot attribute gains or harms.

## Required next iterations

- Maintain the v8 applicability audit and update scores only after access/method verification; never treat decision utility as methodological quality.
- Complete second-reviewer verification of provisional study types and a full-method appraisal for empirical/causal claims; use domain-appropriate risk-of-bias checklists rather than the decision-utility score.
- Add backward/forward snowballing around the 97-paper synthesis set, especially 3D CAD design-intent and mixed-initiative creativity papers.
- Seek stronger empirical evidence for proactive timing and initiative rhythm in creative tasks.
- Add contradictory or null evidence, not only supportive findings.
- Pilot the v9 protocol assumptions (6 tutorial strata, 24 videos, 3 coders) and replace estimated episodes/video and participant ranges with observed variance plus simulation-based power analysis.
- Continue updating the versioned workbook and syncing it to the server every material iteration.
- Retry C19-C22 through OpenAlex after the current API rate limit clears; primary sources were verified through publisher/author repositories and did not inflate PRISMA download counts.

The 30-minute heartbeat must remain active until the user explicitly asks to stop.
