# FlowStudio DC1 continuous literature review state

Last completed iteration: 2026-07-22 (Asia/Shanghai), v5.

## Current counts

- Source records retrieved: 1,431
- Deduplicated records screened: 1,262
- Duplicates removed: 169
- Focused synthesis set: 85
- Query clusters: 20
- Database-query log entries: 41, plus explicit ACM DL / Google Scholar access-limit rows

## Current deliverable

- `outputs/flowstudio_dc1_prisma_20260722/FlowStudio_DC1_PRISMA_Literature_Review_20260722_v5.xlsx`
- Server mirror: `/root/flowstudio_lit_review_20260722/`

## Strongest current synthesis

1. Intent is enacted and revised in a manipulation-feedback-repair loop; it is not always a fixed latent label that precedes action.
2. DC1 needs a hierarchical intent model and latent 3D reference-frame model.
3. Intent content and commitment strength must be modeled separately.
4. Repair events are high-value supervision but must be diagnosed by cause before memory updates.
5. Memory retrieval changes the prior and can create confirmation bias; retrieve supporting, conflicting, and failed episodes.
6. Authority is a function-specific vector, with slow agent escalation and instantaneous human reclaim.
7. Initiative timing and interaction rhythm are as important as initiative level.
8. Evaluation should prioritize calibration, repair burden, commitment violations, agency, and creative exploration—not top-1 intent accuracy alone.
9. Tutorial, VLM-inferred, creator-recalled, and controlled-task intent labels are different evidence tiers and must retain provenance.
10. VLMs should be treated as weak pre-annotators; rare, uncertain, constraint-sensitive, and authority-relevant episodes require human review.
11. Reliability must be computed per representation layer: temporal boundaries, observable events, categorical intent fields, multi-label constraints, ordinal commitment and latent rationale need different metrics.
12. Low agreement in high-level creative intent may be valid plural interpretation; preserve it as alternatives instead of forcing a single label.
13. Case similarity, reuse utility, explanation value and authority are distinct; retrieval updates an intent prior but never grants execution permission.
14. A useful retrieval set is contrastive: one support, one near miss, one failed/repair case and one alternative-intent case, with an authority-boundary case added for high-risk queries.
15. Retention is governed: confirmed outcomes enter success memory, unresolved episodes remain ambiguity cases, failures retain diagnosed repair causes, and redundant/stale cases are merged or quarantined.

## Required next iterations

- Add formal quality/applicability scoring to included literature, with evidence access level and study type.
- Add backward/forward snowballing around the 65-paper synthesis set, especially 3D CAD design-intent and mixed-initiative creativity papers.
- Seek stronger empirical evidence for proactive timing and initiative rhythm in creative tasks.
- Add contradictory or null evidence, not only supportive findings.
- Build a candidate DC1 study protocol and ablation matrix from IN1–IN12.
- Continue updating the versioned workbook and syncing it to the server every material iteration.
- Retry C19/C20 through OpenAlex after the current API rate limit clears; primary sources were verified through publisher/author repositories and did not inflate PRISMA download counts.

The 30-minute heartbeat must remain active until the user explicitly asks to stop.
