#!/usr/bin/env python3
"""Reproducible multi-source search for the FlowStudio DC1 PRISMA review."""

from __future__ import annotations

import csv
import json
import re
import time
import urllib.parse
import urllib.request
import urllib.error
from pathlib import Path


OUT = Path(__file__).resolve().parent / "raw"
OUT.mkdir(parents=True, exist_ok=True)

QUERIES = {
    "C1_3D_mental_models": "3D user interface object manipulation mental model direct manipulation spatial cognition",
    "C2_interaction_signals": "interaction signals intent inference user actions implicit intent interface",
    "C3_mixed_initiative_cocreation": "mixed initiative co-creation creativity support tools human AI",
    "C4_uncertainty_shared_autonomy": "human intent inference uncertainty shared autonomy interaction",
    "C5_agent_memory": "LLM agent memory episodic semantic procedural memory retrieval interaction history",
    "C6_frontend_GUI_intent": "GUI agent user intent inference interface interaction history",
    "C7_creative_agency": "human AI co-creation agency control explainability creative tools",
    "C8_AI_3D_authoring": "AI assisted 3D modeling semantic editing direct manipulation",
    "C9_human_agent_handoff": "human AI handoff authority transfer takeover boundary conditions adjustable autonomy mixed initiative",
    "C10_affordance_embodied": "affordance embodied cognition spatial interaction direct manipulation design",
    "C11_hierarchical_goal_recognition": "hierarchical intent goal plan recognition interaction action sequence GUI",
    "C12_common_ground_repair": "common ground grounding repair misunderstanding human AI collaboration",
    "C13_CAD_design_intent": "CAD design intent feature semantics constraints 3D modeling interaction",
    "C14_agency_ownership": "human AI co-creation agency ownership control creative process",
    "C15_proactive_interruption": "proactive AI initiative interruption timing attention mixed initiative",
    "C16_memory_conflict_bias": "agent memory retrieval conflict provenance stale memory confirmation bias",
    "C17_3D_gesture_ambiguity": "3D gesture sketch ambiguity reference frame constraint intent inference",
    "C18_video_intent_coding_VLM_annotation": "video interaction analysis stimulated recall cognitive task analysis VLM assisted annotation human in the loop intent",
    "C19_coding_reliability_event_boundaries": "intercoder reliability qualitative HCI annotation event segmentation boundary agreement hierarchical task analysis",
    "C20_case_contrastive_retrieval": "case based reasoning intent episodic memory similarity utility contrastive retrieval explanation by example",
}


def get_json(url: str, params: dict[str, str | int], timeout: int = 45) -> dict:
    params = dict(params)
    if "crossref.org" in url:
        params["mailto"] = "research@example.com"
    full = url + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(full, headers={"User-Agent": "FlowStudio-CHI27-literature-review/1.0 (mailto:research@example.com)"})
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.load(resp)
        except urllib.error.HTTPError as exc:
            if exc.code != 429 or attempt == 3:
                raise
            # Both OpenAlex and Crossref may throttle repeated review iterations.
            # Honor rate limiting with bounded exponential backoff rather than
            # leaving the corpus half-updated.
            time.sleep(5 * (2 ** attempt))
    raise RuntimeError("unreachable")


def norm_title(title: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", (title or "").lower()).strip()


def inv_abstract(index: dict | None) -> str:
    if not index:
        return ""
    positions = []
    for word, locs in index.items():
        positions.extend((pos, word) for pos in locs)
    return " ".join(word for _, word in sorted(positions))


records: list[dict] = []
search_log: list[dict] = []

for cluster, query in QUERIES.items():
    oa = get_json("https://api.openalex.org/works", {
        "search": query,
        "per-page": 50,
        "select": "id,doi,title,publication_year,authorships,primary_location,abstract_inverted_index,cited_by_count,type",
    })
    (OUT / f"openalex_{cluster}.json").write_text(json.dumps(oa, ensure_ascii=False, indent=2), encoding="utf-8")
    search_log.append({"database": "OpenAlex", "cluster": cluster, "query": query, "reported_hits": oa.get("meta", {}).get("count"), "records_retrieved": len(oa.get("results", [])), "status": "completed"})
    for w in oa.get("results", []):
        loc = w.get("primary_location") or {}
        src = loc.get("source") or {}
        records.append({
            "database": "OpenAlex", "cluster": cluster, "title": w.get("title") or "",
            "year": w.get("publication_year") or "", "doi": (w.get("doi") or "").replace("https://doi.org/", ""),
            "authors": "; ".join(((a.get("author") or {}).get("display_name") or "") for a in w.get("authorships", [])),
            "venue": src.get("display_name") or "", "url": loc.get("landing_page_url") or w.get("id") or "",
            "abstract": inv_abstract(w.get("abstract_inverted_index")), "citations": w.get("cited_by_count") or 0,
            "work_type": w.get("type") or "",
        })
    time.sleep(0.25)

    try:
        cr = get_json("https://api.crossref.org/works", {"query": query, "rows": 35, "select": "DOI,title,author,published,container-title,URL,type,is-referenced-by-count,abstract"})
        (OUT / f"crossref_{cluster}.json").write_text(json.dumps(cr, ensure_ascii=False, indent=2), encoding="utf-8")
        msg = cr.get("message", {})
        search_log.append({"database": "Crossref", "cluster": cluster, "query": query, "reported_hits": msg.get("total-results"), "records_retrieved": len(msg.get("items", [])), "status": "completed"})
        for w in msg.get("items", []):
            date_parts = (((w.get("published") or {}).get("date-parts") or [[""]])[0])
            authors = "; ".join(" ".join(filter(None, [a.get("given"), a.get("family")])) for a in w.get("author", []))
            records.append({
                "database": "Crossref", "cluster": cluster, "title": (w.get("title") or [""])[0],
                "year": date_parts[0] if date_parts else "", "doi": w.get("DOI") or "", "authors": authors,
                "venue": (w.get("container-title") or [""])[0], "url": w.get("URL") or "",
                "abstract": re.sub(r"<[^>]+>", " ", w.get("abstract") or ""), "citations": w.get("is-referenced-by-count") or 0,
                "work_type": w.get("type") or "",
            })
    except Exception as exc:
        search_log.append({"database": "Crossref", "cluster": cluster, "query": query, "reported_hits": "", "records_retrieved": 0, "status": f"failed: {type(exc).__name__}"})
    time.sleep(1.5)

# Semantic Scholar has tighter unauthenticated limits, so retrieve a smaller auditable sample.
for cluster, query in list(QUERIES.items())[:3]:
    try:
        ss = get_json("https://api.semanticscholar.org/graph/v1/paper/search", {
            "query": query, "limit": 20,
            "fields": "title,year,authors,venue,url,externalIds,abstract,citationCount,publicationTypes",
        }, timeout=15)
        (OUT / f"semanticscholar_{cluster}.json").write_text(json.dumps(ss, ensure_ascii=False, indent=2), encoding="utf-8")
        items = ss.get("data", [])
        search_log.append({"database": "Semantic Scholar", "cluster": cluster, "query": query, "reported_hits": ss.get("total"), "records_retrieved": len(items), "status": "completed"})
        for w in items:
            records.append({
                "database": "Semantic Scholar", "cluster": cluster, "title": w.get("title") or "",
                "year": w.get("year") or "", "doi": (w.get("externalIds") or {}).get("DOI") or "",
                "authors": "; ".join(a.get("name") or "" for a in w.get("authors", [])), "venue": w.get("venue") or "",
                "url": w.get("url") or "", "abstract": w.get("abstract") or "", "citations": w.get("citationCount") or 0,
                "work_type": "; ".join(w.get("publicationTypes") or []),
            })
    except Exception as exc:
        search_log.append({"database": "Semantic Scholar", "cluster": cluster, "query": query, "reported_hits": "", "records_retrieved": 0, "status": f"failed: {type(exc).__name__}"})
    time.sleep(1.2)

with (OUT / "search_log.csv").open("w", newline="", encoding="utf-8-sig") as f:
    writer = csv.DictWriter(f, fieldnames=list(search_log[0]))
    writer.writeheader(); writer.writerows(search_log)

dedup: dict[str, dict] = {}
for r in records:
    key = "doi:" + r["doi"].lower().strip() if r["doi"] else "title:" + norm_title(r["title"])
    if not key or key == "title:":
        continue
    if key not in dedup:
        r["found_in"] = r["database"]
        r["clusters"] = r["cluster"]
        dedup[key] = r
    else:
        old = dedup[key]
        old["found_in"] = "; ".join(sorted(set(old["found_in"].split("; ") + [r["database"]])))
        old["clusters"] = "; ".join(sorted(set(old["clusters"].split("; ") + [r["cluster"]])))
        for field in ("doi", "authors", "venue", "url", "abstract"):
            if not old[field] and r[field]: old[field] = r[field]
        old["citations"] = max(int(old["citations"] or 0), int(r["citations"] or 0))

fields = ["title", "year", "authors", "venue", "doi", "url", "abstract", "citations", "work_type", "found_in", "clusters"]
with (OUT / "combined_candidates.csv").open("w", newline="", encoding="utf-8-sig") as f:
    writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
    writer.writeheader(); writer.writerows(sorted(dedup.values(), key=lambda r: (-int(r["citations"] or 0), str(r["title"]))))

summary = {"queries": len(QUERIES), "source_records": len(records), "deduplicated_records": len(dedup), "searches": search_log}
(OUT / "corpus_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({"source_records": len(records), "deduplicated_records": len(dedup), "searches": len(search_log)}, ensure_ascii=False))
