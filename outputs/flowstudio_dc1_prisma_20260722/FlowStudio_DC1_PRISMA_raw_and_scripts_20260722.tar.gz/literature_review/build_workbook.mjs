import fs from "node:fs/promises";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const root = "/Users/primav/Documents/博一/CHI27-FlowStudio";
const outDir = `${root}/outputs/flowstudio_dc1_prisma_20260722`;
const previewDir = `${outDir}/previews`;
await fs.mkdir(previewDir, { recursive: true });
const data = JSON.parse(await fs.readFile(`${root}/literature_review/raw/workbook_data.json`, "utf8"));

const wb = Workbook.create();
const C = {navy:"#17324D", teal:"#007C83", cyan:"#DDF3F2", gold:"#F2B134", pale:"#F7FAFC", ink:"#18323F", gray:"#5F6B73", line:"#D7E2E8", red:"#B23A48", green:"#2E7D5B", white:"#FFFFFF"};

function title(sheet, text, subtitle, cols) {
  sheet.showGridLines = false;
  sheet.getRange(`A1:${cols}1`).merge();
  sheet.getRange("A1").values=[[text]];
  sheet.getRange("A1").format={fill:C.navy,font:{bold:true,color:C.white,size:18},rowHeight:30,verticalAlignment:"center"};
  sheet.getRange(`A2:${cols}2`).merge();
  sheet.getRange("A2").values=[[subtitle]];
  sheet.getRange("A2").format={fill:C.cyan,font:{color:C.ink,italic:true,size:10},wrapText:true,rowHeight:30,verticalAlignment:"center"};
}
function table(sheet, startRow, headers, rows, name, widths=[]) {
  const matrix=[headers,...rows.map(r=>headers.map(h=>r[h] ?? ""))];
  const endRow=startRow+matrix.length-1;
  const endCol=String.fromCharCode(64+headers.length);
  const range=sheet.getRange(`A${startRow}:${endCol}${endRow}`);
  range.values=matrix;
  range.format={font:{color:C.ink,size:9},verticalAlignment:"top"};
  sheet.getRange(`A${startRow}:${endCol}${startRow}`).format={fill:C.teal,font:{bold:true,color:C.white,size:9},wrapText:true,rowHeight:30,verticalAlignment:"center"};
  if (rows.length) {
    const t=sheet.tables.add(`A${startRow}:${endCol}${endRow}`,true,name); t.style="TableStyleMedium2"; t.showBandedRows=true;
  }
  widths.forEach((w,i)=>sheet.getRangeByIndexes(0,i,endRow,1).format.columnWidth=w);
  sheet.freezePanes.freezeRows(startRow);
  return {endRow,endCol};
}

// 1. Overview
const s0=wb.worksheets.add("README_概览"); title(s0,"FlowStudio DC1 文献综述","PRISMA-inspired rapid scoping review | 检索日 2026-07-21 | 交付日 2026-07-22 | 时区 Asia/Shanghai","H");
s0.getRange("A4:B11").values=[
 ["指标","值"],["来源记录",""],["去重后记录",""],["重点纳入文献",""],["核心研究对象","3D 直接操作信号 → 意图假设 → 记忆检索 → Agent 行动"],["新增主题","Mixed-Initiative Co-creation；Creativity Support Tools；人机接管边界"],["方法定位","PRISMA 启发的快速范围综述；单审阅者 + AI 辅助筛选"],["重要限制","ACM DL 直接站内检索受 Cloudflare 阻断；Google Scholar 连接超时；均已在检索日志中明示"]
];
s0.getRange("B5").formulas=[["='PRISMA流程'!B5"]]; s0.getRange("B6").formulas=[["='PRISMA流程'!B7"]]; s0.getRange("B7").formulas=[["='PRISMA流程'!B12"]];
s0.getRange("A4:B4").format={fill:C.teal,font:{bold:true,color:C.white}}; s0.getRange("A4:B11").format.borders={preset:"insideHorizontal",style:"thin",color:C.line};
s0.getRange("A13:H13").merge(); s0.getRange("A13").values=[["核心结论"]]; s0.getRange("A13").format={fill:C.gold,font:{bold:true,color:C.navy,size:12}};
s0.getRange("A14:H19").values=[
 ["1","单个 3D 动作不是意图。选择、刷选、拖拽只有与对象/部件语义、参考系、约束、设计阶段和历史联合解释时，才构成可靠证据。","","","","","",""] ,
 ["2","DC1 最合适的理论形式不是单标签分类器，而是可修订的多假设模型：P(intent | action, object, stage, constraints, history)。","","","","","",""] ,
 ["3","重复旋转、试拖、比较和撤销常是 epistemic action；系统应先帮助用户看清可能性，而不是把探索误判为承诺。","","","","","",""] ,
 ["4","Agent memory 应区分 episodic（发生过什么）、semantic（稳定偏好/对象知识）和 procedural（成功操作策略），并保留来源、时间和置信度。","","","","","",""] ,
 ["5","接管不是二元开关。应把信号采集、意图分析、方案生成、方案选择和最终应用分配不同自动化等级。","","","","","",""] ,
 ["6","建议默认策略：低置信度→多候选/澄清；中置信度→可逆预览；高置信度且局部可逆→可执行；全局/结构性改变→无论置信度多高都需确认。","","","","","",""]
];
for(let r=14;r<=19;r++){s0.getRange(`B${r}:H${r}`).merge();s0.getRange(`A${r}:H${r}`).format={fill:r%2?C.pale:C.white,wrapText:true,rowHeight:42,borders:{preset:"insideHorizontal",style:"thin",color:C.line}};}
s0.getRange("A:A").format.columnWidth=8; s0.getRange("B:H").format.columnWidth=18; s0.freezePanes.freezeRows(3);

// 2. PRISMA
const sp=wb.worksheets.add("PRISMA流程"); title(sp,"PRISMA 流程与计数","计数以实际下载记录为准，不以数据库报告的宽泛总命中数代替；去重使用 DOI，缺 DOI 时使用规范化标题。","F");
sp.getRange("A4:C12").values=[
 ["阶段","数量","说明"],["识别：下载的来源记录","","OpenAlex + Crossref + Semantic Scholar（失败检索为 0）"],["去重：移除重复",data.prisma.duplicates_removed,"DOI/标题去重"],["筛选：去重后记录","","标题/摘要，AI 辅助 + 单审阅者"],["筛选排除","","主题不符、领域过窄、重复或不足以支撑 DC1 理论"],["报告寻求",data.prisma.reports_sought,"重点理论种子与高相关记录"],["报告未获得",0,"本轮均至少获得摘要/作者版本/扩展摘要；访问层级见纳入文献"],["资格评估",data.prisma.reports_assessed,"快速范围综述，不等同双人注册系统综述"],["综合纳入","","进入理论与设计矩阵"]
];
sp.getRange("B5").formulas=[["=SUM('检索日志'!E5:E40)"]]; sp.getRange("B7").formulas=[["=B5-B6"]]; sp.getRange("B8").formulas=[["=B7-B12"]]; sp.getRange("B12").formulas=[[`=COUNTIF('纳入文献_41'!N5:N${4+data.included.length},\"Include\")`]];
sp.getRange("A4:C4").format={fill:C.teal,font:{bold:true,color:C.white}}; sp.getRange("A5:C12").format={wrapText:true,borders:{preset:"insideHorizontal",style:"thin",color:C.line}};
sp.getRange("A14:F14").merge();sp.getRange("A14").values=[["方法与偏差说明"]];sp.getRange("A14").format={fill:C.gold,font:{bold:true,color:C.navy}};
sp.getRange("A15:F20").values=[
 ["综述类型","PRISMA-inspired rapid scoping review；目标是理论与设计空间映射，不是效应量 meta-analysis。","","","",""],
 ["时间范围","1983–2026；奠基文献通过种子检索与前后向滚雪球补入。","","","",""],
 ["纳入","能解释 3D 操作认知、交互意图推断、混合主动共创、记忆检索或接管边界，并可转化为 DC1 设计要求。","","","",""],
 ["排除","纯模型性能、纯机器人执行、医疗/交通等窄领域信号且无可迁移 HCI 机制、重复或仅泛谈 AI 创意。","","","",""],
 ["偏差","单审阅者；部分数据库不可直接批量访问；引文数仅作定位，不作为质量评分。","","","",""],
 ["下一步","投稿前建议由第二位研究者复核全部纳入/排除边界并补做 ACM DL/Google Scholar 机构账号检索。","","","",""],
 ];
for(let r=15;r<=20;r++){sp.getRange(`B${r}:F${r}`).merge();sp.getRange(`A${r}:F${r}`).format={wrapText:true,rowHeight:38,borders:{preset:"insideHorizontal",style:"thin",color:C.line}};}
sp.getRange("A:A").format.columnWidth=18;sp.getRange("B:B").format.columnWidth=12;sp.getRange("C:F").format.columnWidth=20;sp.freezePanes.freezeRows(4);

// 3. Search log
const sl=wb.worksheets.add("检索日志"); title(sl,"数据库与检索日志","主题簇 C1–C9；reported hits 仅为数据库宽泛估计，PRISMA 计数使用 records retrieved。","G");
const logRows=data.search_log.map(x=>({"数据库":x.database,"主题簇":x.cluster,"检索式":x.query,"报告命中":Number(x.reported_hits)||"","实际下载":Number(x.records_retrieved)||0,"状态":x.status,"限制/替代":""}));
logRows.push(
 {"数据库":"ACM Digital Library","主题簇":"C1–C9","检索式":"站内组合检索（intent inference / mixed initiative / 3D manipulation / creativity support）","报告命中":"","实际下载":0,"状态":"403 / Cloudflare","限制/替代":"用 DOI、OpenAlex/Crossref ACM 出版者元数据及作者版本核验；不计入下载记录"},
 {"数据库":"Google Scholar","主题簇":"C1–C9","检索式":"精确短语 + 主题组合；本机与服务器连接","报告命中":"","实际下载":0,"状态":"连接超时/无法批量复核","限制/替代":"保留失败日志；以 OpenAlex/Crossref/作者页/DOI 交叉核验，不声称完整覆盖"},
 {"数据库":"Semantic Scholar","主题簇":"C1–C3","检索式":"同 OpenAlex 主题簇","报告命中":"","实际下载":0,"状态":"匿名 API HTTPError","限制/替代":"失败检索记 0；不补写虚构命中数"}
);
table(sl,4,["数据库","主题簇","检索式","报告命中","实际下载","状态","限制/替代"],logRows,"SearchLog",[20,24,55,14,14,20,50]);
sl.getRange(`C5:C${4+logRows.length}`).format.wrapText=true;sl.getRange(`G5:G${4+logRows.length}`).format.wrapText=true;

// 4. Screening records
const sr=wb.worksheets.add("筛选记录_648"); title(sr,"去重后筛选记录","每行一条候选文献；排除理由用于复核。摘要为数据库元数据，可能为空。","K");
const screenHeaders=["记录ID","题名","年份","作者","来源","DOI","URL","发现于","主题簇","决定","排除理由"];
const screenRows=data.screened.map(x=>({"记录ID":x.record_id,"题名":x.title,"年份":Number(x.year)||x.year,"作者":x.authors,"来源":x.venue,"DOI":x.doi,"URL":x.url,"发现于":x.found_in,"主题簇":x.clusters,"决定":x.screen_decision,"排除理由":x.exclusion_reason}));
table(sr,4,screenHeaders,screenRows,"ScreenedRecords",[12,48,9,34,28,24,42,20,28,12,48]);
sr.getRange(`B5:K${4+screenRows.length}`).format.wrapText=true;sr.getRange(`J5:J${4+screenRows.length}`).conditionalFormats.add("containsText",{text:"Include",format:{fill:"#DFF3E8",font:{color:C.green,bold:true}}});

// 5. Included papers
const si=wb.worksheets.add("纳入文献_41"); title(si,"重点纳入文献","41 篇理论生成性文献；URL/DOI 可追溯，综合内容为分析性转述。","N");
const ih=["ID","题名","年份","作者","出处","DOI","URL","发现渠道","主题","理论贡献","对 DC1 的启示","接管边界","证据访问","决定"];
const ir=data.included.map(x=>({"ID":x.include_id,"题名":x.title,"年份":Number(x.year)||x.year,"作者":x.authors,"出处":x.venue,"DOI":x.doi,"URL":x.url,"发现渠道":x.found_in,"主题":x.theme,"理论贡献":x.theoretical_contribution,"对 DC1 的启示":x.dc1_implication,"接管边界":x.handoff_boundary,"证据访问":x.evidence_access,"决定":x.screen_decision}));
table(si,4,ih,ir,"IncludedPapers",[9,48,9,30,25,24,40,18,22,52,58,55,26,11]);
si.getRange(`B5:N${4+ir.length}`).format.wrapText=true;si.getRange(`N5:N${4+ir.length}`).conditionalFormats.add("containsText",{text:"Include",format:{fill:"#DFF3E8",font:{color:C.green,bold:true}}});

// 6. Theory matrix
const st=wb.worksheets.add("理论矩阵"); title(st,"理论 → 计算机制 → DC1 可检验主张","将文献综述转化为可以在系统与研究中验证的结构。","G");
const theoryRows=[
 ["Directness / semantic distance","动作与目标语义之间的翻译距离","对象/部件/参考系条件化的事件解释","相同 drag 在不同对象、部件与阶段产生不同意图后验","Hutchins et al.; Shneiderman","意图解释正确率 + 用户修正次数","核心"],
 ["Epistemic action","用户通过行动思考、探测和外化认知","探索状态/承诺状态隐变量；undo/compare/repeat 作为证据","系统区分试探与承诺后可减少错误自动应用","Kirsh & Maglio","误提交率；探索广度；撤销后恢复","核心"],
 ["Situated action","计划在情境中形成并被修订","以当前对象状态、工具、阶段和历史持续更新假设","序列模型优于孤立事件分类","Suchman；本综述推论","序列 vs 单事件消融","补充"],
 ["Bayesian inverse planning","从近似理性动作反推潜在目标","P(intent|trajectory,state,constraints) 多假设推断","保留分布而非 top-1 可改善歧义处理","Baker et al.; Jain & Argall","Top-k、校准误差、熵-错误关系","核心"],
 ["Legibility vs predictability","可预期动作不等于可读意图","交互解释预览；agent edit 的 intent-expressive preview","显示保留/改变范围能提升用户理解与接管效率","Dragan et al.","理解正确率；接管反应时间","核心"],
 ["Mixed-initiative expected utility","主动性依赖收益、不确定性和打扰成本","initiative policy = f(confidence,risk,reversibility,stage)","情境化主动性优于固定主动或固定被动","Horvitz","控制冲突；接受率；打扰评分","核心"],
 ["Levels of automation","感知、分析、决策、执行可不同程度自动化","分层权限：observe→infer→suggest→preview→apply","高分析自动化 + 低最终执行自动化可兼顾效率与控制","Parasuraman et al.","任务时间；控制感；情况感知","核心"],
 ["Calibrated trust","信任应匹配系统能力与情境","置信度、证据、失败模式与可撤销性显示","校准信息能减少过度依赖和不当拒绝","Lee & See; Amershi et al.","适当依赖率；信任校准","核心"],
 ["COFI / reciprocal co-creation","共创由轮次、贡献类型和沟通结构组成","定义 agent 何时提议/修改/评价/选择","显式协作协议能减少主动权冲突","Rezwana & Maher; Deterding et al.","协作流畅度；agency；ownership","核心"],
 ["Typed agent memory","情节、语义、程序记忆承担不同功能","分库写入与混合检索；来源/时间/置信度","类型化记忆优于扁平聊天历史","Generative Agents; MemGPT; memory surveys","检索准确、利用率、过时记忆错误","核心"],
 ["3D task taxonomy & constraints","导航、选择、操控与系统控制需要区分","事件归一化 + reference-frame/constraint/part reasoning","加入几何约束和任务模式能降低动作歧义","Bowman; Mendes; iWIRES","歧义率；约束破坏率","核心"],
 ["Sketch ambiguity","同一笔迹可表示创建、细化或变形","按阶段维持 operation-family 分布并给对比预览","对比预览优于静默单一解释","Olsen et al.; Teddy","修正次数；首次意图命中","核心"]
];
table(st,4,["理论","核心构念","计算化机制","DC1 可检验主张","关键来源","建议指标","优先级"],theoryRows.map(r=>Object.fromEntries(["理论","核心构念","计算化机制","DC1 可检验主张","关键来源","建议指标","优先级"].map((h,i)=>[h,r[i]]))),"TheoryMatrix",[28,38,52,56,34,30,12]);
st.getRange("A5:G30").format.wrapText=true;

// 7. Signal-intent-memory mapping
const sm=wb.worksheets.add("信号_意图_记忆"); title(sm,"交互信号 → 意图假设 → 记忆","信号从来不是单独的命令；必须与对象、时序、设计阶段和历史一起解释。","H");
const signalRows=[
 ["Select / hover","对象或部件是当前关注目标","语义部件、邻接、可供性、先前选择","工作记忆 + 情节","object/part id；stage；recency","中：选中不等于要修改","显示当前 scope，并允许扩/缩范围","Selection is deictic focus"],
 ["Brush / lasso","局部工作区、边界或语义焦点","覆盖率、边界、部件分割、刷速、重复","情节","spatial overlap；part semantics","高：替换/精修/标注多义","输出多个 operation-family 预览","Teddy; sketch surveys"],
 ["Drag vector","移动、缩放、拉伸、姿态或表达性变化","屏幕向量、物体轴、视角、约束、手柄、幅度","情节 + 程序","trajectory similarity；reference frame","高：2D→3D 深度/轴歧义","约束化预览；必要时选轴","van Emmerik; Reisman"],
 ["Repeated micro-adjustment","精修、寻找阈值或系统误解","往返、幅度衰减、undo、停顿","情节","temporal pattern；same target","中：可能是认知探测","降低 agent 主动性，保留连续控制","Epistemic action"],
 ["Compare / accept / reject","偏好、方向承诺或反例","候选差异、决策时间、后续回退","情节→语义偏好","similar past alternatives；stage","中：一次选择未必稳定","局部更新；重复后才固化长期偏好","CST; co-creation"],
 ["Undo / restore","结果不合意、范围错误或探索结束","撤销链、撤销速度、是否继续同方向","情节 + 程序失败","edit provenance；failure similarity","高：原因不可直接观测","询问/推断原因但不永久归因","Interactive ML"],
 ["Camera navigation","观察、检查遮挡或比较视角","相机状态、对象是否固定、当前模式","工作记忆","viewpoint；visibility","高：不得当作对象操作","硬规则隔离 navigation 与 edit","Bowman taxonomy"],
 ["Tool / mode","限制可行操作族","active tool、gizmo、selection mode","程序","tool-operation compatibility","低到中","作为强先验但允许例外","3D UI taxonomy"],
 ["Geometry / constraints","可行且结构合理的改变","对称、接触、对齐、拓扑、接口","语义 + 程序","constraint graph；part relation","高：错误会破坏结构","默认保留；破坏需确认","iWIRES; CAD intent"],
 ["Design stage / commitment","发散范围与保真度","已接受结构、编辑历史、候选收敛","语义状态","stage match；commitment strength","高：阶段误判会过度发散","阶段可见、可手动修正","CST; staged divergence"],
 ["Past episodes / preferences","个性化意图先验","相似对象/部件/阶段及用户反馈","情节/语义/程序分层","relevance+recency+importance+stage","高：陈旧/冲突记忆","显示来源；衰减；当前证据优先","Generative Agents; MemGPT"]
];
const sh=["信号","候选意图","联合上下文","记忆类型","检索键","主要风险","系统响应","理论依据"];
table(sm,4,sh,signalRows.map(r=>Object.fromEntries(sh.map((h,i)=>[h,r[i]]))),"SignalIntentMemory",[24,38,48,24,42,38,50,32]);sm.getRange("A5:H30").format.wrapText=true;

// 8. Handoff boundaries
const hb=wb.worksheets.add("接管边界"); title(hb,"人机接管 / Authority Transfer 边界条件","阈值为待实验校准的设计假设，不是既定事实。原则：最小必要权限、可见理由、可逆性和随时返还控制。","H");
const boundaryRows=[
 ["意图置信度/熵","低或多个假设接近","只观察、提问、展示对比候选","不执行","Bayesian intent inference","高","用校准曲线而非裸 softmax"],
 ["可逆性","完全可撤销且局部","可自动生成并预览；用户允许时应用","预览/局部执行","Mixed initiative; direct manipulation","中","撤销必须真实恢复几何、语义和记忆"],
 ["影响范围","跨部件、全局比例、拓扑或已接受结构","解释影响并请求确认","显式确认","Variable autonomy","高","blast radius 比置信度更优先"],
 ["设计承诺","已选择/反复保留/进入精修","锁定已承诺结构；只开放选定部分","人主导","Creativity support","高","允许用户显式重新打开设计空间"],
 ["结构约束","可能破坏对称、接触、接口或拓扑","提供保约束版本与破约束版本","确认后破约束","Structure-aware editing","高","约束不是永恒真理，但破坏必须可见"],
 ["模型分布外/解释失败","新工具、异常轨迹、上下文冲突","降级到建议/手动；记录未知","人接管","Human-AI uncertainty","高","不能解释时不应以高置信度执行"],
 ["记忆冲突/陈旧","当前行为与长期偏好冲突","当前会话优先；显示冲突并允许修正","暂停长期记忆影响","Agent memory","高","每条记忆保留来源、时间、版本"],
 ["时间压力","任务紧迫但错误可恢复","提高建议/预览速度，不越过确认边界","动态但受上限约束","Mixed initiative","中","时间压力不授权不可逆结构改动"],
 ["用户注意/中断成本","用户在连续精细操作中","延迟非关键建议；不中断控制流","等待","Horvitz","中","在自然断点介入"],
 ["控制冲突","用户立即反向操作、撤销或抢回 gizmo","Agent 立刻停止并返还控制","强制人接管","Adjustable autonomy","高","抢回优先级最高，无辩论式阻塞"],
 ["Agent 贡献 legibility","用户无法预测会改变什么","只给 before/after、scope、保留项解释","禁止应用","Legibility","高","先让系统意图可读，再谈自动化"],
 ["重复成功证据","同类场景多次接受且无纠正","可逐步提高局部可逆自动化","可学习升级","SARI; IML","中","升级需可撤销、可重置、可审计"]
];
const bh=["边界变量","触发条件","允许的 Agent 行为","权限/接管级别","理论来源","风险","实现备注"];
table(hb,4,bh,boundaryRows.map(r=>Object.fromEntries(bh.map((h,i)=>[h,r[i]]))),"HandoffBoundaries",[26,45,55,28,35,12,52]);hb.getRange("A5:G30").format.wrapText=true;
hb.getRange("A19:H19").merge();hb.getRange("A19").values=[["推荐权限阶梯"]];hb.getRange("A19").format={fill:C.gold,font:{bold:true,color:C.navy}};
hb.getRange("A20:F25").values=[
 ["L0 Observe","只记录信号和状态","无外显干预","默认起点","任何情境",""],
 ["L1 Infer","形成并显示多假设","用户可修正","低置信度/高歧义","不改变模型",""],
 ["L2 Suggest","提出操作/检索结果","不生成最终改动","中等置信度","用户忙碌时延迟",""],
 ["L3 Preview","生成可逆候选/ghost preview","不写入已承诺模型","中高置信度","推荐默认 Agent 主动级",""],
 ["L4 Apply local","执行局部、可逆、低 blast-radius 操作","完整 undo + 日志","高置信度且有重复成功证据","用户可全局关闭",""],
 ["L5 Structural apply","全局/拓扑/已承诺结构修改","必须显式确认","无论模型置信度","最高风险",""],
];
hb.getRange("A20:F25").format={wrapText:true,borders:{preset:"insideHorizontal",style:"thin",color:C.line}};

// 9. DC1 requirements
const dr=wb.worksheets.add("DC1设计要求"); title(dr,"DC1：从三维认知心智模型解释直觉型交互信号","可直接转写进论文的 design requirements / hypotheses 草案。","G");
const reqRows=[
 ["DR1","将意图表示为可修订的概率假设，而不是固定命令","每个假设含 target、operation family、scope、preserve constraints、confidence、evidence","Baker; Jain & Argall","核心架构"],
 ["DR2","用对象/部件语义和 3D 参考系解释动作","同时编码 screen/world/object/local frame 与 active constraints","van Emmerik; Bowman; Reisman","交互理解"],
 ["DR3","区分 epistemic exploration 与 pragmatic commitment","从重复、停顿、比较、撤销和幅度变化估计承诺状态","Kirsh & Maglio","避免过早执行"],
 ["DR4","检索相似情节必须匹配对象、部件、阶段与意图，而非只做文本相似","hybrid score = semantic relevance + stage + recency + importance + provenance","Generative Agents; memory survey","记忆检索"],
 ["DR5","分离 episodic / semantic / procedural memory","情节保存发生过什么；语义保存稳定偏好；程序保存验证过的策略","Memory Matters; MemGPT","记忆架构"],
 ["DR6","让系统意图 legible","执行前显示改变范围、保留项、约束、理由和候选差异","Dragan; Amershi","可理解与纠错"],
 ["DR7","按功能分配自动化，不做全局二元接管","信号采集与分析可高自动；方案选择和结构应用由人把关","Parasuraman; adjustable autonomy","接管边界"],
 ["DR8","Agent 主动性由置信度 × 可逆性 × 影响范围 × 打扰成本共同决定","低置信度提问；中等预览；高置信局部可逆执行；结构改动确认","Horvitz; Lee & See","主动策略"],
 ["DR9","把 accept/reject/undo/correction 作为带来源的学习信号","一次反馈只更新情节；跨情节稳定后再更新长期偏好/程序","Interactive ML; SARI","在线学习"],
 ["DR10","维护并尊重设计承诺，同时允许显式重新打开局部空间","accepted structure 转为 guardrail；selected part 可 reopen","CST; COFI; staged divergence","创造性与控制"],
 ["H1","联合上下文模型优于单事件模型","比较 action-only vs action+geometry+stage+history 的 top-k 与校准","理论矩阵","技术评估"],
 ["H2","多假设预览比 top-1 自动应用减少错误并提高控制感","测修正率、控制感、任务时间和探索广度","Mixed initiative","用户研究"],
 ["H3","类型化记忆比扁平历史提高相关检索并减少过时偏好干扰","离线检索评测 + 长程任务","Agent memory","技术评估"],
 ["H4","阶段/承诺感知的主动策略比固定主动策略提高 agency 且不降低产出质量","三条件：prompt-only / fixed initiative / adaptive initiative","CST + autonomy","用户研究"]
];
const rh=["编号","要求/假设","操作化","理论来源","验证位置"];
table(dr,4,rh,reqRows.map(r=>Object.fromEntries(rh.map((h,i)=>[h,r[i]]))),"DC1Requirements",[10,52,62,36,28]);dr.getRange("A5:E30").format.wrapText=true;

// Compact verification and previews for every sheet.
for (const name of ["README_概览","PRISMA流程","检索日志","筛选记录_648","纳入文献_41","理论矩阵","信号_意图_记忆","接管边界","DC1设计要求"]) {
  const sheet=wb.worksheets.getItem(name);
  const used=sheet.getUsedRange();
  const preview=await wb.render({sheetName:name,range:"A1:H22",scale:1,format:"png"});
  await fs.writeFile(`${previewDir}/${name}.png`,new Uint8Array(await preview.arrayBuffer()));
}
const check=await wb.inspect({kind:"table",range:"PRISMA流程!A4:C12",include:"values,formulas",tableMaxRows:15,tableMaxCols:5,maxChars:5000});
console.log(check.ndjson);
const errors=await wb.inspect({kind:"match",searchTerm:"#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",options:{useRegex:true,maxResults:100},summary:"final formula error scan",maxChars:4000});
console.log(errors.ndjson);
const file=await SpreadsheetFile.exportXlsx(wb);
await file.save(`${outDir}/FlowStudio_DC1_PRISMA_Literature_Review_20260722.xlsx`);
console.log(JSON.stringify({output:`${outDir}/FlowStudio_DC1_PRISMA_Literature_Review_20260722.xlsx`,sheets:9,included:data.included.length,screened:data.screened.length}));
