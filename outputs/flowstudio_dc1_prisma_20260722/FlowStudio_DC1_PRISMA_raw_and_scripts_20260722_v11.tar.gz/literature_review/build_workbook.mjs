import fs from "node:fs/promises";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const root = "/Users/primav/Documents/博一/CHI27-FlowStudio";
const outDir = `${root}/outputs/flowstudio_dc1_prisma_20260722`;
const previewDir = `${outDir}/previews`;
await fs.mkdir(previewDir, { recursive: true });
const data = JSON.parse(await fs.readFile(`${root}/literature_review/raw/workbook_data.json`, "utf8"));
const includedSheetName = `纳入文献_${data.included.length}`;
const screenedSheetName = `筛选记录_${data.screened.length}`;

const wb = Workbook.create();
const C = {navy:"#17324D", teal:"#007C83", cyan:"#DDF3F2", gold:"#F2B134", pale:"#F7FAFC", ink:"#18323F", gray:"#5F6B73", line:"#D7E2E8", red:"#B23A48", green:"#2E7D5B", white:"#FFFFFF"};

function title(sheet, text, subtitle, cols) {
  sheet.showGridLines = false;
  sheet.getRange(`A1:${cols}1`).merge();
  sheet.getRange("A1").values=[[text]];
  sheet.getRange("A1").format={fill:C.navy,font:{bold:true,color:C.white,size:18},rowHeight:30,verticalAlignment:"center"};
  sheet.getRange(`A2:${cols}2`).merge();
  sheet.getRange("A2").values=[[subtitle]];
  sheet.getRange("A2").format={fill:C.cyan,font:{color:C.ink,italic:true,size:10},wrapText:true,rowHeight:30,verticalAlignment:"center"};
}
function table(sheet, startRow, headers, rows, name, widths=[]) {
  const matrix=[headers,...rows.map(r=>headers.map(h=>r[h] ?? ""))];
  const endRow=startRow+matrix.length-1;
  const endCol=String.fromCharCode(64+headers.length);
  const range=sheet.getRange(`A${startRow}:${endCol}${endRow}`);
  range.values=matrix;
  range.format={font:{color:C.ink,size:9},verticalAlignment:"top"};
  sheet.getRange(`A${startRow}:${endCol}${startRow}`).format={fill:C.teal,font:{bold:true,color:C.white,size:9},wrapText:true,rowHeight:30,verticalAlignment:"center"};
  if (rows.length) {
    const t=sheet.tables.add(`A${startRow}:${endCol}${endRow}`,true,name); t.style="TableStyleMedium2"; t.showBandedRows=true;
  }
  widths.forEach((w,i)=>sheet.getRangeByIndexes(0,i,endRow,1).format.columnWidth=w);
  sheet.freezePanes.freezeRows(startRow);
  return {endRow,endCol};
}

function provisionalStudyType(p) {
  const t=`${p.title} ${p.theme} ${p.theoretical_contribution}`.toLowerCase();
  if (/systematic review|literature review|\bsurvey\b|review of/.test(t)) return "Review / synthesis";
  if (/experiment|effects? on|evaluation|user stud|controlled|empirical/.test(t)) return "Empirical evaluation";
  if (/goal recognition|plan recognition|inverse planning|classifier|benchmark|algorithm|probabilistic/.test(t)) return "Computational / technical";
  if (/principles|guidelines|framework|taxonomy|model for|theory|conceptual/.test(t)) return "Theory / framework";
  return "Design / system paper";
}
function evidenceRole(p) {
  const t=`${p.title} ${p.theme} ${p.theoretical_contribution}`.toLowerCase();
  if (/3d|spatial|mental model|direct manipulation|epistemic|affordance/.test(t)) return "3D cognition / action theory";
  if (/intent|goal recognition|plan recognition|belief|signal/.test(t)) return "Intent inference mechanism";
  if (/memory|retriev|case-based|contrastive/.test(t)) return "Memory / case retrieval";
  if (/mixed|creativ|co-creat|initiative/.test(t)) return "Co-creation / initiative";
  if (/authority|handoff|takeover|shared control|autonomy|agency|ownership/.test(t)) return "Authority / agency boundary";
  if (/video|annotation|coding|reliab|recall|task analysis/.test(t)) return "Coding / evidence method";
  return "Supporting HCI theory";
}
function directness(p) {
  const t=`${p.title} ${p.theme} ${p.theoretical_contribution} ${p.dc1_implication}`.toLowerCase();
  if (/3d|spatial|mental model|direct manipulation|epistemic|affordance|intent|goal recognition|plan recognition|reference frame/.test(t)) return 3;
  if (/memory|retriev|mixed|creativ|authority|handoff|autonomy|video|coding|annotation|agency/.test(t)) return 2;
  return 1;
}
function transferability(p) {
  const t=`${p.title} ${p.theme} ${p.dc1_implication}`.toLowerCase();
  if (/3d|interface|interaction|design|creative|direct manipulation|epistemic|goal recognition|intent/.test(t)) return 3;
  if (/robot|automation|vehicle|driving|medical/.test(t)) return 2;
  return 2;
}

const manualAppraisals = {
  I11: {
    heuristicType:"Empirical evaluation", verifiedType:"Controlled lab experiment",
    designSample:"Dynamic control simulation; N=30 participants; multiple levels-of-automation conditions with automation-failure trials.",
    comparisonAnalysis:"Between-condition performance, situation awareness and workload; recovery after automation failure.",
    allowedClaim:"Controlled evidence about level-of-automation trade-offs and failure recovery.",
    keyFinding:"Implementation automation improved normal performance but could weaken recovery after automation failure; joint human-system option generation also produced coordination costs.",
    transferLimit:"Dynamic-control task, not creative 3D authoring; transfer the failure-recovery mechanism, not its effect size.",
    url:"https://pubmed.ncbi.nlm.nih.gov/10048306/", status:"Full abstract and method summary verified"
  },
  I21: {
    heuristicType:"Empirical evaluation", verifiedType:"Literature review / mapping review",
    designSample:"Mapping review of 143 ACM Digital Library papers published 1999–2018.",
    comparisonAnalysis:"Literature coding and landscape synthesis; no primary controlled user experiment in this paper.",
    allowedClaim:"Field scope, recurring CST activities and research gaps; not a direct causal effect.",
    keyFinding:"Creativity support must be evaluated across activity, context and process, not only artifact output.",
    transferLimit:"The review maps CST research broadly and does not validate FlowStudio's intent representation.",
    url:"https://pure.au.dk/portal/en/publications/mapping-the-landscape-of-creativity-support-tools-in-hci/", status:"Review scope and corpus size verified"
  },
  I22: {
    heuristicType:"Design / system paper", verifiedType:"Mixed computational + formative expert study",
    designSample:"Controlled algorithm tests plus 5 game-industry experts completing 24 level-design sessions.",
    comparisonAnalysis:"Playability/evolutionary-algorithm evaluation plus qualitative expert interaction with generated alternatives.",
    allowedClaim:"Formative evidence that optional alternatives can support inspiration and expose constraints.",
    keyFinding:"Experts sometimes used suggestions as inspiration but often overlooked them; locking accepted features was a salient control need.",
    transferLimit:"Small expert sample and game-level task; insufficient for causal claims about general creativity or automatic intent inference.",
    url:"https://www.antoniosliapis.com/papers/sentient_sketchbook.pdf", status:"Full author paper verified; prior title–DOI mismatch removed"
  },
  I24: {
    heuristicType:"Empirical evaluation", verifiedType:"Formative mixed-method system evaluation",
    designSample:"Approximately 30 informal demonstrations, a formative study with 6 novice users, and an expert-juried competition.",
    comparisonAnalysis:"Qualitative/formative assessment of reciprocal drawing interaction and perceived collaboration.",
    allowedClaim:"Design feasibility and formative interaction observations; not a population-level effect.",
    keyFinding:"Real-time co-creation benefits from explicit feedback, pause/correction and adjustable contribution behavior.",
    transferLimit:"Small, descriptive drawing study; artistic sketching differs from constrained 3D editing.",
    url:"https://doi.org/10.1145/2757226.2764555", status:"Full short paper verified"
  },
  I69: {
    heuristicType:"Empirical evaluation", verifiedType:"Qualitative process evaluation",
    designSample:"13 family physicians, 17 patients and 17 matched consultations using video-stimulated recall.",
    comparisonAnalysis:"Thematic/process analysis of what recall added beyond observed consultation video.",
    allowedClaim:"Methodological value of stimulated recall for eliciting participant interpretations.",
    keyFinding:"Recall can reveal reasoning unavailable from observation alone, but remains retrospective and context-dependent.",
    transferLimit:"Clinical conversations, not 3D authoring; supports triangulation, not ground-truth access to latent intent.",
    url:"https://journals.sagepub.com/doi/10.1177/1609406917719623", status:"Abstract and method summary verified"
  },
  I86: {
    heuristicType:"Empirical evaluation", verifiedType:"Multi-experiment human–robot study",
    designSample:"Two disaster-response-inspired experiments: one simulated robot and one physical mobile robot.",
    comparisonAnalysis:"Variable-autonomy switching conditions assessed task performance, workload and concurrent-task costs.",
    allowedClaim:"Empirical evidence that initiative/switching policy affects performance, workload and control conflict.",
    keyFinding:"Context-aware switching can help, but authority transitions themselves create conflicts-for-control that must be designed and surfaced.",
    transferLimit:"Robot navigation differs from creative 3D work; exact sample and condition details require a second-reviewer extraction pass before effect-size claims.",
    url:"https://arxiv.org/abs/1911.04848", status:"Full author version and two-experiment structure verified"
  },
  I87: {
    heuristicType:"Empirical evaluation", verifiedType:"Structured literature review",
    designSample:"Review and analysis of 76 empirical human-autonomy-teaming studies.",
    comparisonAnalysis:"Structured synthesis of empirical HAT constructs, processes and outcomes.",
    allowedClaim:"Recurring HAT factors and gaps across a body of studies; not a new primary experiment.",
    keyFinding:"Team performance depends on shared understanding, communication, coordination and repair, beyond component accuracy.",
    transferLimit:"Heterogeneous teaming domains; conclusions inform constructs but do not directly set FlowStudio thresholds.",
    url:"https://journals.sagepub.com/doi/10.1177/0018720820960865", status:"Review method and 76-study corpus verified"
  }
};

// 1. Overview
const s0=wb.worksheets.add("README_概览"); title(s0,"FlowStudio DC1 文献综述","PRISMA-inspired rapid scoping review | 检索日 2026-07-21 | 交付日 2026-07-22 | 时区 Asia/Shanghai","H");
s0.getRange("A4:B11").values=[
 ["指标","值"],["来源记录",""],["去重后记录",""],["重点纳入文献",""],["核心研究对象","3D 直接操作信号 → 意图假设 → 记忆检索 → Agent 行动"],["新增主题","Mixed-Initiative Co-creation；Creativity Support Tools；人机接管边界"],["方法定位","PRISMA 启发的快速范围综述；单审阅者 + AI 辅助筛选"],["重要限制","ACM DL 直接站内检索受 Cloudflare 阻断；Google Scholar 连接超时；均已在检索日志中明示"]
];
s0.getRange("B5").formulas=[["='PRISMA流程'!B5"]]; s0.getRange("B6").formulas=[["='PRISMA流程'!B7"]]; s0.getRange("B7").formulas=[["='PRISMA流程'!B12"]];
s0.getRange("A4:B4").format={fill:C.teal,font:{bold:true,color:C.white}}; s0.getRange("A4:B11").format.borders={preset:"insideHorizontal",style:"thin",color:C.line};
s0.getRange("A13:H13").merge(); s0.getRange("A13").values=[["核心结论"]]; s0.getRange("A13").format={fill:C.gold,font:{bold:true,color:C.navy,size:12}};
s0.getRange("A14:H19").values=[
 ["1","单个 3D 动作不是意图。选择、刷选、拖拽只有与对象/部件语义、参考系、约束、设计阶段和历史联合解释时，才构成可靠证据。","","","","","",""] ,
 ["2","DC1 最合适的理论形式不是单标签分类器，而是可修订的多假设模型：P(intent | action, object, stage, constraints, history)。","","","","","",""] ,
 ["3","重复旋转、试拖、比较和撤销常是 epistemic action；系统应先帮助用户看清可能性，而不是把探索误判为承诺。","","","","","",""] ,
 ["4","Agent memory 应区分 episodic（发生过什么）、semantic（稳定偏好/对象知识）和 procedural（成功操作策略），并保留来源、时间和置信度。","","","","","",""] ,
 ["5","接管不是二元开关。应把信号采集、意图分析、方案生成、方案选择和最终应用分配不同自动化等级。","","","","","",""] ,
 ["6","建议默认策略：低置信度→多候选/澄清；中置信度→可逆预览；高置信度且局部可逆→可执行；全局/结构性改变→无论置信度多高都需确认。","","","","","",""]
];
for(let r=14;r<=19;r++){s0.getRange(`B${r}:H${r}`).merge();s0.getRange(`A${r}:H${r}`).format={fill:r%2?C.pale:C.white,wrapText:true,rowHeight:42,borders:{preset:"insideHorizontal",style:"thin",color:C.line}};}
s0.getRange("A:A").format.columnWidth=8; s0.getRange("B:H").format.columnWidth=18; s0.freezePanes.freezeRows(3);

// 2. PRISMA
const sp=wb.worksheets.add("PRISMA流程"); title(sp,"PRISMA 流程与计数","计数以实际下载记录为准，不以数据库报告的宽泛总命中数代替；去重使用 DOI，缺 DOI 时使用规范化标题。","F");
sp.getRange("A4:C12").values=[
 ["阶段","数量","说明"],["识别：下载的来源记录","","OpenAlex + Crossref + Semantic Scholar（失败检索为 0）"],["去重：移除重复",data.prisma.duplicates_removed,"DOI/标题去重"],["筛选：去重后记录","","标题/摘要，AI 辅助 + 单审阅者"],["筛选排除","","主题不符、领域过窄、重复或不足以支撑 DC1 理论"],["报告寻求",data.prisma.reports_sought,"重点理论种子与高相关记录"],["报告未获得",0,"本轮均至少获得摘要/作者版本/扩展摘要；访问层级见纳入文献"],["资格评估",data.prisma.reports_assessed,"快速范围综述，不等同双人注册系统综述"],["综合纳入","","进入理论与设计矩阵"]
];
sp.getRange("B5").formulas=[["=SUM('检索日志'!E5:E60)"]]; sp.getRange("B7").formulas=[["=B5-B6"]]; sp.getRange("B8").formulas=[["=B7-B12"]]; sp.getRange("B12").formulas=[[`=COUNTIF('${includedSheetName}'!N5:N${4+data.included.length},\"Include\")`]];
sp.getRange("A4:C4").format={fill:C.teal,font:{bold:true,color:C.white}}; sp.getRange("A5:C12").format={wrapText:true,borders:{preset:"insideHorizontal",style:"thin",color:C.line}};
sp.getRange("A14:F14").merge();sp.getRange("A14").values=[["方法与偏差说明"]];sp.getRange("A14").format={fill:C.gold,font:{bold:true,color:C.navy}};
sp.getRange("A15:F20").values=[
 ["综述类型","PRISMA-inspired rapid scoping review；目标是理论与设计空间映射，不是效应量 meta-analysis。","","","",""],
 ["时间范围","1983–2026；奠基文献通过种子检索与前后向滚雪球补入。","","","",""],
 ["纳入","能解释 3D 操作认知、交互意图推断、混合主动共创、记忆检索或接管边界，并可转化为 DC1 设计要求。","","","",""],
 ["排除","纯模型性能、纯机器人执行、医疗/交通等窄领域信号且无可迁移 HCI 机制、重复或仅泛谈 AI 创意。","","","",""],
 ["偏差","单审阅者；部分数据库不可直接批量访问；引文数仅作定位，不作为质量评分。","","","",""],
 ["下一步","投稿前建议由第二位研究者复核全部纳入/排除边界并补做 ACM DL/Google Scholar 机构账号检索。","","","",""],
 ];
for(let r=15;r<=20;r++){sp.getRange(`B${r}:F${r}`).merge();sp.getRange(`A${r}:F${r}`).format={wrapText:true,rowHeight:38,borders:{preset:"insideHorizontal",style:"thin",color:C.line}};}
sp.getRange("A:A").format.columnWidth=18;sp.getRange("B:B").format.columnWidth=12;sp.getRange("C:F").format.columnWidth=20;sp.freezePanes.freezeRows(4);

// 3. Search log
const sl=wb.worksheets.add("检索日志"); title(sl,"数据库与检索日志","主题簇 C1–C22；reported hits 仅为数据库宽泛估计，PRISMA 计数使用 records retrieved。","G");
const logRows=data.search_log.map(x=>({"数据库":x.database,"主题簇":x.cluster,"检索式":x.query,"报告命中":Number(x.reported_hits)||"","实际下载":Number(x.records_retrieved)||0,"状态":x.status,"限制/替代":""}));
logRows.push(
 {"数据库":"ACM Digital Library","主题簇":"C1–C9","检索式":"站内组合检索（intent inference / mixed initiative / 3D manipulation / creativity support）","报告命中":"","实际下载":0,"状态":"403 / Cloudflare","限制/替代":"用 DOI、OpenAlex/Crossref ACM 出版者元数据及作者版本核验；不计入下载记录"},
 {"数据库":"Google Scholar","主题簇":"C1–C9","检索式":"精确短语 + 主题组合；本机与服务器连接","报告命中":"","实际下载":0,"状态":"连接超时/无法批量复核","限制/替代":"保留失败日志；以 OpenAlex/Crossref/作者页/DOI 交叉核验，不声称完整覆盖"},
 {"数据库":"Semantic Scholar","主题簇":"C1–C3","检索式":"同 OpenAlex 主题簇","报告命中":"","实际下载":0,"状态":"匿名 API HTTPError","限制/替代":"失败检索记 0；不补写虚构命中数"}
);
table(sl,4,["数据库","主题簇","检索式","报告命中","实际下载","状态","限制/替代"],logRows,"SearchLog",[20,24,55,14,14,20,50]);
sl.getRange(`C5:C${4+logRows.length}`).format.wrapText=true;sl.getRange(`G5:G${4+logRows.length}`).format.wrapText=true;

// 4. Screening records
const sr=wb.worksheets.add(screenedSheetName); title(sr,"去重后筛选记录","每行一条候选文献；排除理由用于复核。摘要为数据库元数据，可能为空。","K");
const screenHeaders=["记录ID","题名","年份","作者","来源","DOI","URL","发现于","主题簇","决定","排除理由"];
const screenRows=data.screened.map(x=>({"记录ID":x.record_id,"题名":x.title,"年份":Number(x.year)||x.year,"作者":x.authors,"来源":x.venue,"DOI":x.doi,"URL":x.url,"发现于":x.found_in,"主题簇":x.clusters,"决定":x.screen_decision,"排除理由":x.exclusion_reason}));
table(sr,4,screenHeaders,screenRows,"ScreenedRecords",[12,48,9,34,28,24,42,20,28,12,48]);
sr.getRange(`B5:K${4+screenRows.length}`).format.wrapText=true;sr.getRange(`J5:J${4+screenRows.length}`).conditionalFormats.add("containsText",{text:"Include",format:{fill:"#DFF3E8",font:{color:C.green,bold:true}}});

// 5. Included papers
const si=wb.worksheets.add(includedSheetName); title(si,"重点纳入文献",`${data.included.length} 篇理论生成性文献；URL/DOI 可追溯，综合内容为分析性转述。`,"N");
const ih=["ID","题名","年份","作者","出处","DOI","URL","发现渠道","主题","理论贡献","对 DC1 的启示","接管边界","证据访问","决定"];
const ir=data.included.map(x=>({"ID":x.include_id,"题名":x.title,"年份":Number(x.year)||x.year,"作者":x.authors,"出处":x.venue,"DOI":x.doi,"URL":x.url,"发现渠道":x.found_in,"主题":x.theme,"理论贡献":x.theoretical_contribution,"对 DC1 的启示":x.dc1_implication,"接管边界":x.handoff_boundary,"证据访问":x.evidence_access,"决定":x.screen_decision}));
table(si,4,ih,ir,"IncludedPapers",[9,48,9,30,25,24,40,18,22,52,58,55,26,11]);
si.getRange(`B5:N${4+ir.length}`).format.wrapText=true;si.getRange(`N5:N${4+ir.length}`).conditionalFormats.add("containsText",{text:"Include",format:{fill:"#DFF3E8",font:{color:C.green,bold:true}}});

// 6. Theory matrix
const st=wb.worksheets.add("理论矩阵"); title(st,"理论 → 计算机制 → DC1 可检验主张","将文献综述转化为可以在系统与研究中验证的结构。","G");
const theoryRows=[
 ["Directness / semantic distance","动作与目标语义之间的翻译距离","对象/部件/参考系条件化的事件解释","相同 drag 在不同对象、部件与阶段产生不同意图后验","Hutchins et al.; Shneiderman","意图解释正确率 + 用户修正次数","核心"],
 ["Epistemic action","用户通过行动思考、探测和外化认知","探索状态/承诺状态隐变量；undo/compare/repeat 作为证据","系统区分试探与承诺后可减少错误自动应用","Kirsh & Maglio","误提交率；探索广度；撤销后恢复","核心"],
 ["Situated action","计划在情境中形成并被修订","以当前对象状态、工具、阶段和历史持续更新假设","序列模型优于孤立事件分类","Suchman；本综述推论","序列 vs 单事件消融","补充"],
 ["Bayesian inverse planning","从近似理性动作反推潜在目标","P(intent|trajectory,state,constraints) 多假设推断","保留分布而非 top-1 可改善歧义处理","Baker et al.; Jain & Argall","Top-k、校准误差、熵-错误关系","核心"],
 ["Legibility vs predictability","可预期动作不等于可读意图","交互解释预览；agent edit 的 intent-expressive preview","显示保留/改变范围能提升用户理解与接管效率","Dragan et al.","理解正确率；接管反应时间","核心"],
 ["Mixed-initiative expected utility","主动性依赖收益、不确定性和打扰成本","initiative policy = f(confidence,risk,reversibility,stage)","情境化主动性优于固定主动或固定被动","Horvitz","控制冲突；接受率；打扰评分","核心"],
 ["Levels of automation","感知、分析、决策、执行可不同程度自动化","分层权限：observe→infer→suggest→preview→apply","高分析自动化 + 低最终执行自动化可兼顾效率与控制","Parasuraman et al.","任务时间；控制感；情况感知","核心"],
 ["Calibrated trust","信任应匹配系统能力与情境","置信度、证据、失败模式与可撤销性显示","校准信息能减少过度依赖和不当拒绝","Lee & See; Amershi et al.","适当依赖率；信任校准","核心"],
 ["COFI / reciprocal co-creation","共创由轮次、贡献类型和沟通结构组成","定义 agent 何时提议/修改/评价/选择","显式协作协议能减少主动权冲突","Rezwana & Maher; Deterding et al.","协作流畅度；agency；ownership","核心"],
 ["Typed agent memory","情节、语义、程序记忆承担不同功能","分库写入与混合检索；来源/时间/置信度","类型化记忆优于扁平聊天历史","Generative Agents; MemGPT; memory surveys","检索准确、利用率、过时记忆错误","核心"],
 ["3D task taxonomy & constraints","导航、选择、操控与系统控制需要区分","事件归一化 + reference-frame/constraint/part reasoning","加入几何约束和任务模式能降低动作歧义","Bowman; Mendes; iWIRES","歧义率；约束破坏率","核心"],
 ["Sketch ambiguity","同一笔迹可表示创建、细化或变形","按阶段维持 operation-family 分布并给对比预览","对比预览优于静默单一解释","Olsen et al.; Teddy","修正次数；首次意图命中","核心"]
];
table(st,4,["理论","核心构念","计算化机制","DC1 可检验主张","关键来源","建议指标","优先级"],theoryRows.map(r=>Object.fromEntries(["理论","核心构念","计算化机制","DC1 可检验主张","关键来源","建议指标","优先级"].map((h,i)=>[h,r[i]]))),"TheoryMatrix",[28,38,52,56,34,30,12]);
st.getRange("A5:G30").format.wrapText=true;

// 7. Signal-intent-memory mapping
const sm=wb.worksheets.add("信号_意图_记忆"); title(sm,"交互信号 → 意图假设 → 记忆","信号从来不是单独的命令；必须与对象、时序、设计阶段和历史一起解释。","H");
const signalRows=[
 ["Select / hover","对象或部件是当前关注目标","语义部件、邻接、可供性、先前选择","工作记忆 + 情节","object/part id；stage；recency","中：选中不等于要修改","显示当前 scope，并允许扩/缩范围","Selection is deictic focus"],
 ["Brush / lasso","局部工作区、边界或语义焦点","覆盖率、边界、部件分割、刷速、重复","情节","spatial overlap；part semantics","高：替换/精修/标注多义","输出多个 operation-family 预览","Teddy; sketch surveys"],
 ["Drag vector","移动、缩放、拉伸、姿态或表达性变化","屏幕向量、物体轴、视角、约束、手柄、幅度","情节 + 程序","trajectory similarity；reference frame","高：2D→3D 深度/轴歧义","约束化预览；必要时选轴","van Emmerik; Reisman"],
 ["Repeated micro-adjustment","精修、寻找阈值或系统误解","往返、幅度衰减、undo、停顿","情节","temporal pattern；same target","中：可能是认知探测","降低 agent 主动性，保留连续控制","Epistemic action"],
 ["Compare / accept / reject","偏好、方向承诺或反例","候选差异、决策时间、后续回退","情节→语义偏好","similar past alternatives；stage","中：一次选择未必稳定","局部更新；重复后才固化长期偏好","CST; co-creation"],
 ["Undo / restore","结果不合意、范围错误或探索结束","撤销链、撤销速度、是否继续同方向","情节 + 程序失败","edit provenance；failure similarity","高：原因不可直接观测","询问/推断原因但不永久归因","Interactive ML"],
 ["Camera navigation","观察、检查遮挡或比较视角","相机状态、对象是否固定、当前模式","工作记忆","viewpoint；visibility","高：不得当作对象操作","硬规则隔离 navigation 与 edit","Bowman taxonomy"],
 ["Tool / mode","限制可行操作族","active tool、gizmo、selection mode","程序","tool-operation compatibility","低到中","作为强先验但允许例外","3D UI taxonomy"],
 ["Geometry / constraints","可行且结构合理的改变","对称、接触、对齐、拓扑、接口","语义 + 程序","constraint graph；part relation","高：错误会破坏结构","默认保留；破坏需确认","iWIRES; CAD intent"],
 ["Design stage / commitment","发散范围与保真度","已接受结构、编辑历史、候选收敛","语义状态","stage match；commitment strength","高：阶段误判会过度发散","阶段可见、可手动修正","CST; staged divergence"],
 ["Past episodes / preferences","个性化意图先验","相似对象/部件/阶段及用户反馈","情节/语义/程序分层","relevance+recency+importance+stage","高：陈旧/冲突记忆","显示来源；衰减；当前证据优先","Generative Agents; MemGPT"]
];
const sh=["信号","候选意图","联合上下文","记忆类型","检索键","主要风险","系统响应","理论依据"];
table(sm,4,sh,signalRows.map(r=>Object.fromEntries(sh.map((h,i)=>[h,r[i]]))),"SignalIntentMemory",[24,38,48,24,42,38,50,32]);sm.getRange("A5:H30").format.wrapText=true;

// 8. Handoff boundaries
const hb=wb.worksheets.add("接管边界"); title(hb,"人机接管 / Authority Transfer 边界条件","阈值为待实验校准的设计假设，不是既定事实。原则：最小必要权限、可见理由、可逆性和随时返还控制。","H");
const boundaryRows=[
 ["意图置信度/熵","低或多个假设接近","只观察、提问、展示对比候选","不执行","Bayesian intent inference","高","用校准曲线而非裸 softmax"],
 ["可逆性","完全可撤销且局部","可自动生成并预览；用户允许时应用","预览/局部执行","Mixed initiative; direct manipulation","中","撤销必须真实恢复几何、语义和记忆"],
 ["影响范围","跨部件、全局比例、拓扑或已接受结构","解释影响并请求确认","显式确认","Variable autonomy","高","blast radius 比置信度更优先"],
 ["设计承诺","已选择/反复保留/进入精修","锁定已承诺结构；只开放选定部分","人主导","Creativity support","高","允许用户显式重新打开设计空间"],
 ["结构约束","可能破坏对称、接触、接口或拓扑","提供保约束版本与破约束版本","确认后破约束","Structure-aware editing","高","约束不是永恒真理，但破坏必须可见"],
 ["模型分布外/解释失败","新工具、异常轨迹、上下文冲突","降级到建议/手动；记录未知","人接管","Human-AI uncertainty","高","不能解释时不应以高置信度执行"],
 ["记忆冲突/陈旧","当前行为与长期偏好冲突","当前会话优先；显示冲突并允许修正","暂停长期记忆影响","Agent memory","高","每条记忆保留来源、时间、版本"],
 ["时间压力","任务紧迫但错误可恢复","提高建议/预览速度，不越过确认边界","动态但受上限约束","Mixed initiative","中","时间压力不授权不可逆结构改动"],
 ["用户注意/中断成本","用户在连续精细操作中","延迟非关键建议；不中断控制流","等待","Horvitz","中","在自然断点介入"],
 ["控制冲突","用户立即反向操作、撤销或抢回 gizmo","Agent 立刻停止并返还控制","强制人接管","Adjustable autonomy","高","抢回优先级最高，无辩论式阻塞"],
 ["Agent 贡献 legibility","用户无法预测会改变什么","只给 before/after、scope、保留项解释","禁止应用","Legibility","高","先让系统意图可读，再谈自动化"],
 ["重复成功证据","同类场景多次接受且无纠正","可逐步提高局部可逆自动化","可学习升级","SARI; IML","中","升级需可撤销、可重置、可审计"]
];
const bh=["边界变量","触发条件","允许的 Agent 行为","权限/接管级别","理论来源","风险","实现备注"];
table(hb,4,bh,boundaryRows.map(r=>Object.fromEntries(bh.map((h,i)=>[h,r[i]]))),"HandoffBoundaries",[26,45,55,28,35,12,52]);hb.getRange("A5:G30").format.wrapText=true;
hb.getRange("A19:H19").merge();hb.getRange("A19").values=[["推荐权限阶梯"]];hb.getRange("A19").format={fill:C.gold,font:{bold:true,color:C.navy}};
hb.getRange("A20:F25").values=[
 ["L0 Observe","只记录信号和状态","无外显干预","默认起点","任何情境",""],
 ["L1 Infer","形成并显示多假设","用户可修正","低置信度/高歧义","不改变模型",""],
 ["L2 Suggest","提出操作/检索结果","不生成最终改动","中等置信度","用户忙碌时延迟",""],
 ["L3 Preview","生成可逆候选/ghost preview","不写入已承诺模型","中高置信度","推荐默认 Agent 主动级",""],
 ["L4 Apply local","执行局部、可逆、低 blast-radius 操作","完整 undo + 日志","高置信度且有重复成功证据","用户可全局关闭",""],
 ["L5 Structural apply","全局/拓扑/已承诺结构修改","必须显式确认","无论模型置信度","最高风险",""],
];
hb.getRange("A20:F25").format={wrapText:true,borders:{preset:"insideHorizontal",style:"thin",color:C.line}};

// 9. DC1 requirements
const dr=wb.worksheets.add("DC1设计要求"); title(dr,"DC1：从三维认知心智模型解释直觉型交互信号","可直接转写进论文的 design requirements / hypotheses 草案。","G");
const reqRows=[
 ["DR1","将意图表示为可修订的概率假设，而不是固定命令","每个假设含 target、operation family、scope、preserve constraints、confidence、evidence","Baker; Jain & Argall","核心架构"],
 ["DR2","用对象/部件语义和 3D 参考系解释动作","同时编码 screen/world/object/local frame 与 active constraints","van Emmerik; Bowman; Reisman","交互理解"],
 ["DR3","区分 epistemic exploration 与 pragmatic commitment","从重复、停顿、比较、撤销和幅度变化估计承诺状态","Kirsh & Maglio","避免过早执行"],
 ["DR4","检索相似情节必须匹配对象、部件、阶段与意图，而非只做文本相似","hybrid score = semantic relevance + stage + recency + importance + provenance","Generative Agents; memory survey","记忆检索"],
 ["DR5","分离 episodic / semantic / procedural memory","情节保存发生过什么；语义保存稳定偏好；程序保存验证过的策略","Memory Matters; MemGPT","记忆架构"],
 ["DR6","让系统意图 legible","执行前显示改变范围、保留项、约束、理由和候选差异","Dragan; Amershi","可理解与纠错"],
 ["DR7","按功能分配自动化，不做全局二元接管","信号采集与分析可高自动；方案选择和结构应用由人把关","Parasuraman; adjustable autonomy","接管边界"],
 ["DR8","Agent 主动性由置信度 × 可逆性 × 影响范围 × 打扰成本共同决定","低置信度提问；中等预览；高置信局部可逆执行；结构改动确认","Horvitz; Lee & See","主动策略"],
 ["DR9","把 accept/reject/undo/correction 作为带来源的学习信号","一次反馈只更新情节；跨情节稳定后再更新长期偏好/程序","Interactive ML; SARI","在线学习"],
 ["DR10","维护并尊重设计承诺，同时允许显式重新打开局部空间","accepted structure 转为 guardrail；selected part 可 reopen","CST; COFI; staged divergence","创造性与控制"],
 ["DR11","把教程、VLM推断和创作者确认作为不同证据层保存","intent_source = tutorial narration / inferred / task ground truth / stimulated recall；保留模型与人工编辑版本","Interaction Analysis; ACTA; stimulated recall","意图编码"],
 ["DR12","VLM只做弱预标注并通过不确定性驱动人工复核","VLM生成边界、观察信号、Top-k意图与反证；高风险、罕见和分歧case进入盲法人工审核","Video Annotator; VideoCoT","数据构建"],
 ["DR13","把episode边界可靠性与意图语义可靠性分开评估","边界用容忍窗口F1/segmentation similarity；类别用α/κ；多标签用逐标签α与Jaccard；latent intent保留分歧","Artstein & Poesio; Fournier & Inkpen; McDonald et al.","标注质控"],
 ["DR14","案例检索必须优化当前决策效用而非表面相似度","硬过滤风险/约束/来源；混合匹配语义、部位、阶段、frame、轨迹和结果；同时返回支持、近失、失败和替代意图案例","Aamodt & Plaza; Cunningham; Miller","案例检索"],
 ["DR15","权限必须表示为可审计的功能向量与状态转移，而非全局自动化等级","authority=[observe,infer,retrieve,generate,select,apply,remember]；每次转移记录initiator、trigger、scope、reason和reclaim","Abbink; Flemisch; Chiou et al.","接管机制"],
 ["DR16","Intent Hypothesis Graph必须同时表示用户目标假设、用户可能的世界/工具信念和证据缺失","节点含observation/context/goal/target/effect/frame/constraint/evidence/outcome/repair/provenance；边含supports/contradicts/refines/supersedes/preserves/violates","Baker et al.; Ramírez & Geffner; Pereira et al.","中间表示"],
 ["H1","联合上下文模型优于单事件模型","比较 action-only vs action+geometry+stage+history 的 top-k 与校准","理论矩阵","技术评估"],
 ["H2","多假设预览比 top-1 自动应用减少错误并提高控制感","测修正率、控制感、任务时间和探索广度","Mixed initiative","用户研究"],
 ["H3","类型化记忆比扁平历史提高相关检索并减少过时偏好干扰","离线检索评测 + 长程任务","Agent memory","技术评估"],
 ["H4","阶段/承诺感知的主动策略比固定主动策略提高 agency 且不降低产出质量","三条件：prompt-only / fixed initiative / adaptive initiative","CST + autonomy","用户研究"]
];
const rh=["编号","要求/假设","操作化","理论来源","验证位置"];
table(dr,4,rh,reqRows.map(r=>Object.fromEntries(rh.map((h,i)=>[h,r[i]]))),"DC1Requirements",[10,52,62,36,28]);dr.getRange("A5:E30").format.wrapText=true;

// 10. Cross-paper insights
const ki=wb.worksheets.add("关键Insights"); title(ki,"跨文献关键 Insights","不是逐篇摘要：每条都包含理论张力、计算机制、可证伪预测和对 FlowStudio 的具体影响。","H");
const insights=[
 ["IN1","意图不是隐藏在动作之前的固定标签，而是在操控—反馈—修复循环中逐步形成。","传统 goal recognition 假定先有目标；distributed cognition、epistemic action 与共创研究强调意图可被行动塑造。","维护 evolving intent state；允许假设分裂、合并和撤回。","序列/反馈模型将在设计中后期显著优于单事件分类；早期优势主要体现在歧义校准。","若系统把第一下 drag 固化为目标，会压缩探索并增加撤销。","Hutchins; Kirsh & Maglio; Hollan et al.; COFI"],
 ["IN2","3D 意图是层级的，参考系也是潜变量；局部运动置信度不能替代高层目标置信度。","同一屏幕轨迹可对应 world/object/local frame 下的移动、变形或姿态；goal-schema 研究支持多层目标。","联合推断 project→stage→edit→motor 与 frame/constraint。","分层模型在跨对象、跨阶段和视角变化时更稳健；只在固定任务上 flat classifier 可能相当。","接管权限取所有层级中最薄弱的一层，而不是 top-1 motor confidence。","Bowman; van Emmerik; Reisman; hierarchical goal recognition"],
 ["IN3","探索性动作和提交性动作需要两个独立变量：intent content 与 commitment strength。","epistemic action 可能与最终操作方向相同，但其功能是获取信息；CST 研究强调早期模糊性。","belief over intent × belief over commitment；commitment 从接受、重复保留、阶段收敛估计。","显式建模 commitment 会降低误提交，但可能增加确认成本。","高 intent confidence + 低 commitment 仍只应预览。","Kirsh & Maglio; sketching reviews; creativity support"],
 ["IN4","修复是最高价值的监督信号，但不能直接等同为反向偏好。","undo、counter-drag、reselect 既可能否定目标，也可能否定范围、幅度、参考系或结果质量。","repair diagnosis：target/scope/operation/frame/constraint/outcome 六类原因后验。","原因分解比把 undo 当负标签更能提升后续个性化。","检测到 repair 时清空当前执行权限，并阻止该 episode 写入稳定偏好。","Grounding; multimodal repair; Interactive ML"],
 ["IN5","Agent memory 不只是回忆模块，它改变意图先验，因此会制造确认偏差。","相似历史被检索后，系统更容易重复旧解释；陈旧偏好可压过当前新方向。","contrastive retrieval：同时取支持、反对和失败案例；显示 provenance/age。","反例检索会降低短期 top-1 confidence，但改善校准和用户改向能力。","记忆冲突时降级到 suggest/preview；当前显式证据优先。","Generative Agents; RAG; MemoryBank; memory surveys"],
 ["IN6","应分离 commitment memory、preference memory 与 skill memory。","已接受结构是本项目承诺；风格选择可能是可变偏好；成功操作策略是程序知识，三者寿命和权限不同。","三类写入门槛、衰减、作用域和撤销机制。","扁平长期记忆更容易产生跨项目污染和错误自动化。","commitment 默认不衰减但项目内可重开；preference 衰减；skill 需跨案例验证。","SARI; AI as Social Glue; MemGPT; Reflexion"],
 ["IN7","接管边界是功能特定且不对称的：Agent 获得权限应慢，用户夺回权限应瞬时。","levels of automation 区分感知、分析、选择、执行；adjustable autonomy 强调权限转移和控制冲突。","独立 authority vector [observe,infer,retrieve,generate,select,apply,remember]。","功能级权限比单一 autonomy level 减少冲突并保持情况感知。","任何 counter-action/undo 立即将 apply 权限归零；升级需重复成功证据。","Parasuraman; Endsley & Kaber; adjustable autonomy"],
 ["IN8","Legibility 必须是双向的：Agent 读懂人，也要让人读懂 Agent。","intent inference 文献多关注机器理解用户；legible motion 和 HAI guidelines 要求系统意图可读。","before/after + scope + preserve + evidence + confidence + memory source。","双向可读性会增加少量交互成本，但缩短错误后的 repair time。","无法解释影响范围时禁止 apply，即使内部置信度高。","Dragan; Amershi; DirectGPT; AI Chains"],
 ["IN9","混合主动性的关键变量不仅是“主动程度”，还有介入节奏和自然断点。","共同创作需要 turn-taking；主动助手研究显示相关性相同但时机不同会改变信任与 agency。","initiative scheduler 识别 pause、candidate decision、stage transition 等 breakpoint。","breakpoint-triggered initiative 比实时连续介入更能保持 flow 和 ownership。","高频精细操控期间只被动记录；比较/停顿阶段可主动提供候选。","Horvitz; COFI; proactive assistants; proactive co-creation"],
 ["IN10","最优 Agent 动作可能不是完成任务，而是用低成本候选最大化信息增益。","shared autonomy 的 information gathering 与 CST 的多候选探索可以统一。","U(m)=task_gain + λ·information_gain − risk − interruption − agency_loss − irreversibility。","高歧义时，contrastive preview 将比 clarification question 获得更自然的设计反馈。","只有低成本、可逆的 probe 可由 Agent 主动发起。","Balanced Information Gathering; mixed initiative; CST"],
 ["IN11","准确率不是 DC1 的首要终点；校准、修复负担和承诺保护更接近真实价值。","错误 top-1 可被轻松修复时危害小；高置信结构性误解危害大。","风险加权评估：ECE/Brier + repair steps + commitment violations + agency。","校准更好的较低准确率模型可能带来更高用户控制和创作质量。","技术评估必须按 blast radius 和 commitment 加权错误。","Jain & Argall; Lee & See; HAI guidelines"],
 ["IN12","设计空间应把“重新打开”作为一等操作，而不是把历史偏好永久化。","共创和发散研究显示创作者在全局收敛后仍会局部重新发散。","reopen(part, constraints, memory_scope) 显式修改承诺边界与检索范围。","显式 reopen 能避免系统把探索误判为用户不一致。","reopen 只解除选定范围，不自动遗忘其他承诺。","CST; staged divergence; typed memory"]
 ,["IN13","意图标签需要证据分级：教程提供可公开表达的操作—目标关系，真实会话提供自然歧义，stimulated recall 提供参与者解释，受控任务提供已知目标。","任何单一来源都不能同时兼顾规模、生态有效性与latent-intent效度；VLM还能引入系统性幻觉和粒度噪声。","case.provenance = {source, intent_source, evidence_strength, vlm_version, human_edits, validation_status}；检索和评估按证据层过滤。","分层证据与主动复核将降低表面数据量，但显著减少约束漏报、虚构证据和错误权限升级。","只有creator-confirmed或controlled-ground-truth案例可用于评估高层意图和接管边界；tutorial/VLM-only案例只用于候选生成。","Jordan & Henderson; Militello & Hutton; Calderhead; Paskins et al.; Video Annotator; VideoCoT"]
 ,["IN14","可靠性必须按表示层计算，而不是给整套意图编码一个κ。","事件边界、可观察信号、层级目标、多标签约束、序数承诺和latent rationale具有不同数据结构；低一致性既可能是codebook问题，也可能是真实歧义。","quality = {boundary_agreement, observable_alpha, labelwise_alpha, constraint_recall, alternative_intent_coverage, adjudication_log}；保留原始双编码和分歧。","分层质控会揭示：低层事件通常可稳定标注，而高层创作目标更适合作为候选分布；强制单标签可能提升表面一致性却降低生态效度。","仅高一致性观察字段可直接进入检索过滤；低一致性意图字段进入Top-k和询问策略，不能驱动自动接管。","McDonald et al.; Hayes & Krippendorff; Artstein & Poesio; O'Connor & Joffe; Fournier & Inkpen; Sasmita & Swallow"]
 ,["IN15","案例的相似度、可复用性、解释价值和授权价值是四个不同变量。","CBR要求retrieve后仍需reuse/revise/retain；向量上相似的案例可能frame不同、约束冲突或结局失败，而失败/近失案例反而最能解释当前歧义。","先hard_filter(source_quality, risk, constraint_compatibility)，再hybrid_score；返回support + near_miss + failed_repair + alternative_intent，最后由LLM比较差异并更新先验。","对比检索可能降低即时top-1置信度和增加少量延迟，但应改善校准、约束召回和错误后的修复负担。","任何历史case都不能直接授权执行；权限仍由当前commitment、risk、reversibility与用户反馈决定。","Aamodt & Plaza; de Mántaras et al.; Cunningham; Smyth; Miller; Keane & Kenny"]
 ,["IN16","控制权转移需要滞回与不对称性：Agent升级应慢且逐级，用户降级/抢回应立即且可跨级。","shared-control与variable-autonomy研究表明切换本身会产生协调成本和控制冲突；频繁来回切换会破坏可预测性与责任对应。","authority_transition = f(current_level, initiator, intent_confidence, commitment, risk, reversibility, availability, recent_repairs)；设置cooldown和升级证据门槛；reclaim事件直接清零apply/select。","滞回会稍微延迟自动化收益，但应降低切换次数、冲突、惊讶和高风险误执行。","高层目标、方案选择和动作应用分别授权；用户反向操作、undo或grab tool优先于任何Agent协商。","Chiou et al.; Abbink et al.; Flemisch et al.; O'Neill et al.; Valero-Gomez et al."]
 ,["IN17","Intent Hypothesis Graph应区分‘用户想要什么’与‘用户认为当前世界是什么样’，并显式保留unknown mass。","逆向规划通常假定观察者模型和行动模型；真实3D界面存在隐藏modifier、遮挡、模式误解、工具映射变化和不完整日志，集中posterior可能只是错误模型下的假确定。","每个hypothesis关联goal belief、world/tool belief、observation coverage和model_fit；posterior之外保留unknown/other；timing与case retrieval只改变likelihood。","加入belief/missingness会降低部分样本置信度，但应显著减少reference-frame误解和OOD高置信错误。","model mismatch、关键证据不可见或unknown mass高时只能observe/suggest/preview，不能apply或写稳定偏好。","Baker et al.; Ramírez & Geffner; Jain & Argall; Pereira et al.; Sohrabi et al.; Goal Recognition with Timing"]
];
const kh=["ID","Insight","理论张力/证据","计算机制","可证伪预测","设计/风险含义","关键文献"];
table(ki,4,kh,insights.map(r=>Object.fromEntries(kh.map((h,i)=>[h,r[i]]))),"KeyInsights",[9,55,58,55,55,55,40]);ki.getRange("A5:G30").format.wrapText=true;

// 11. Mechanism model
const mm=wb.worksheets.add("机制模型"); title(mm,"DC1 机制模型：Signals → Hierarchical Intent → Memory → Initiative","推荐把意图解释器实现为闭环 belief-and-authority system，而不是一次 LLM 分类调用。","H");
const mechanism=[
 ["M1 Signal normalization","把 select/brush/drag/undo/camera/tool/state 转成带时间、目标与 delta 的事件","event_id, actor, timestamp, modality, target, geometry_delta, view, tool","原始事件日志","不做语义结论"],
 ["M2 Context graph","维护对象—部件—约束—阶段—候选—承诺关系","part graph, constraint graph, stage, accepted/reopened scope","当前场景 + 项目状态","导航与编辑模式硬隔离"],
 ["M3 Hierarchical hypothesis","生成多层意图与参考系假设","project_goal, stage_goal, edit_goal, operation, frame, scope, confidence","M1+M2","保留 top-k 和熵"],
 ["M4 Contrastive memory retrieval","每个假设检索支持/反例/失败 episode","episode, preference, skill, provenance, age, outcome","typed memories","当前显式证据权重最高"],
 ["M5 Belief update","融合动作似然、结构可行性、记忆和 repair","posterior hypotheses + commitment strength","M3+M4","repair 触发重新解释"],
 ["M6 Grounding state","判断人机是否对 target/scope/preserve/action 达到足够共同基础","grounded fields, unresolved fields, repair count","preview/correction history","按风险决定 grounding depth"],
 ["M7 Initiative arbitration","计算 observe/ask/suggest/preview/apply 的效用","task gain, info gain, confidence, risk, reversibility, interruption, agency cost","M5+M6+authority policy","最小必要权限"],
 ["M8 Legible preview","展示将改变/保留什么以及证据和记忆来源","before-after, scope, constraints, alternatives, uncertainty","候选生成器","无法解释则禁止 apply"],
 ["M9 Commit / repair","用户接受、修改、撤销或重开范围","decision, correction type, reopened scope","交互反馈","用户抢回控制立即生效"],
 ["M10 Governed memory write","按反馈质量写入 episode/preference/skill/commitment","type, scope, provenance, confidence, expiry, version","M9","一次反馈不升级长期自动化"]
];
const mh=["模块","职责","核心表示","输入/来源","安全边界"];
table(mm,4,mh,mechanism.map(r=>Object.fromEntries(mh.map((h,i)=>[h,r[i]]))),"MechanismModel",[26,52,62,42,52]);mm.getRange("A5:E30").format.wrapText=true;
mm.getRange("A17:H17").merge();mm.getRange("A17").values=[["建议的接管效用函数（待实证校准）"]];mm.getRange("A17").format={fill:C.gold,font:{bold:true,color:C.navy}};
mm.getRange("A18:H20").merge();mm.getRange("A18").values=[["U(mode) = E[task gain] + λ·I(intent; user response) − α·error risk − β·interruption cost − γ·agency loss − δ·irreversibility − η·memory conflict.  权限还受硬约束：结构/拓扑/已承诺范围修改必须确认；任何 user reclaim 信号立即撤销 apply 权限。"]];mm.getRange("A18:H20").format={fill:C.pale,wrapText:true,font:{color:C.ink,size:11},borders:{preset:"outside",style:"medium",color:C.teal}};

// 12. Intent case retrieval specification
const crs=wb.worksheets.add("案例检索规范"); title(crs,"Intent Case Library：检索、对比、修订与保留","案例相似度不是授权。先做风险/约束/来源硬过滤，再混合排序并返回对比集合；LLM只据此更新当前意图先验。","H");
const hardFilters=[
 ["F1","证据质量","exclude/quarantine","case_quality=exclude 或来源/标注版本不可追溯","避免低质量case污染推断"],
 ["F2","约束兼容性","exclude actionable reuse","历史操作破坏当前明确 preserve constraints","仍可作为失败/反例解释"],
 ["F3","作用域与风险","exclude apply template","历史case的blast radius高于当前授权范围","可保留为需确认案例"],
 ["F4","数据泄漏","exclude evaluation retrieval","同一创作者/原视频episode进入测试查询的检索库","按video/creator分组切分"],
 ["F5","记忆状态","down-rank/quarantine","陈旧、冲突、已撤回或用户要求遗忘","当前显式证据优先"]
];
const hf=["规则","硬过滤维度","动作","触发条件","备注"];
table(crs,4,hf,hardFilters.map(r=>Object.fromEntries(hf.map((h,i)=>[h,r[i]]))),"CaseHardFilters",[10,25,26,62,46]);
crs.getRange("A11:H11").merge();crs.getRange("A11").values=[["混合检索权重（初始假设；通过离线检索和用户研究校准）"]];crs.getRange("A11").format={fill:C.gold,font:{bold:true,color:C.navy}};
const scoreRows=[
 ["S1","语义目标/desired effect",0.25,"embedding + controlled vocabulary","区分‘变大’与‘更突出/更稳重’"],
 ["S2","target/part/scope",0.15,"结构化精确/层级匹配","对象相似但部位不同需降权"],
 ["S3","design stage",0.10,"类别匹配/邻近阶段","发散探索case不直接迁移到精修"],
 ["S4","reference frame",0.10,"world/local/view/normal/semantic axis","3D动作解释的关键潜变量"],
 ["S5","preserve constraints",0.15,"集合覆盖+冲突惩罚","冲突先硬过滤，覆盖不足再降权"],
 ["S6","event trajectory",0.10,"时序/事件序列相似度","包含停顿、比较、撤销与修复"],
 ["S7","outcome/repair",0.10,"成功、修复原因和用户反馈","成功模板与失败解释分开使用"],
 ["S8","user/recency/provenance",0.05,"个性化+时间衰减+证据层","不能压过当前显式意图"]
];
const sf=["ID","评分分量","初始权重","实现建议","边界说明"];
table(crs,12,sf,scoreRows.map(r=>Object.fromEntries(sf.map((h,i)=>[h,r[i]]))),"CaseScoreWeights",[10,34,16,48,56]);
crs.getRange("A21:B21").values=[["权重合计",""]];crs.getRange("C21").formulas=[["=SUM(C13:C20)"]];crs.getRange("A21:C21").format={fill:C.cyan,font:{bold:true,color:C.ink}};crs.getRange("C13:C21").format.numberFormat="0%";
crs.getRange("A23:H23").merge();crs.getRange("A23").values=[["每次建议返回的对比案例集合"]];crs.getRange("A23").format={fill:C.gold,font:{bold:true,color:C.navy}};
const contrastRows=[
 ["Support",1,"支持当前Top-1且结果被接受","提供可复用操作与保留约束","不能独占检索结果"],
 ["Near miss",1,"大部分相似但关键frame/scope/constraint不同","指出决定性差异","优先用于澄清"],
 ["Failed/repair",1,"相似操作导致撤销、参数或约束修复","预测失败模式","禁止当成功模板"],
 ["Alternative intent",1,"相同可观察信号但最终意图不同","防止确认偏差并维护Top-k","候选接近时必须返回"],
 ["Authority boundary",0,"相似case发生抢回、拒绝或高风险确认","决定observe/preview/ask","高风险查询时强制加入"]
];
const cf=["case_role","默认数量","选择条件","推理用途","安全规则"];
table(crs,24,cf,contrastRows.map(r=>Object.fromEntries(cf.map((h,i)=>[h,r[i]]))),"ContrastSet",[24,16,56,46,48]);
crs.getRange("A31:H31").merge();crs.getRange("A31").values=[["推荐消融：Dense-only → +结构上下文 → +frame/constraints → +对比集合 → +类型化/个性化记忆"]];crs.getRange("A31").format={fill:C.teal,font:{bold:true,color:C.white},wrapText:true};
crs.getRange("A32:H35").values=[
 ["主要指标","Top-k intent recall；MRR；ECE/Brier","约束召回/违反率","严重权限错误率","修复步数/撤销","检索延迟","用户理解/纠错率","案例覆盖与冗余"],
 ["必须报告","按source_type分层","按task/stage分层","按风险等级分层","成功/修复/拒绝分层","P50/P95","案例解释是否帮助纠错","新增case的边际能力"],
 ["Retention","只有确认结果进入成功库","未决case留在歧义库","失败保留repair cause","用户撤回可删除个性记忆","合并冗余case","记录版本与来源","定期coverage审计"],
 ["运行时边界","retrieval更新prior","LLM比较差异","policy独立算authority","高风险仍需确认","用户抢回立即停止","不以旧case反驳当前用户","不自动固化单次偏好"]
];crs.getRange("A32:H35").format={wrapText:true,borders:{preset:"insideHorizontal",style:"thin",color:C.line}};crs.getRange("A:A").format.columnWidth=20;crs.getRange("B:H").format.columnWidth=24;

// 13. Authority state machine
const as=wb.worksheets.add("权限状态机"); title(as,"Authority State Machine：权限向量、转移与人类抢回","Intent Hypothesis Graph回答“用户可能想做什么”；Authority Policy单独回答“Agent现在被允许做多少”。升级慢且逐级，用户抢回立即且可跨级。","H");
const vectorRows=[
 ["observe","读取界面、事件和3D状态","默认允许","数据权限/隐私关闭","停止采集并清除未授权缓存"],
 ["infer","形成Top-k意图和commitment假设","observe有效且schema可用","OOD/证据冲突","输出unknown，不伪造结论"],
 ["retrieve","访问案例与类型化记忆","来源可追溯、当前任务允许","用户关闭记忆/冲突或陈旧","不调用长期记忆，当前证据优先"],
 ["generate","生成候选但不改变主模型","至少一个合理假设且可安全沙盒","高风险且无法隔离预览","仅解释/询问"],
 ["select","替用户选择候选","用户明确授权或重复稳定接受","候选接近、commitment低、repair","退回用户选择"],
 ["apply","写入当前3D模型","高置信+高commitment+低风险+可逆+局部","undo/counter-drag/grab tool/结构风险","立即归零并返还控制"],
 ["remember","写入长期偏好/程序/承诺","结果确认且满足对应写入门槛","未决、一次性反馈、撤回、repair未诊断","只保留带provenance的episode或不写"]
];
const avh=["权限维度","能力","默认","禁止/降级条件","安全动作"];
table(as,4,avh,vectorRows.map(r=>Object.fromEntries(avh.map((h,i)=>[h,r[i]]))),"AuthorityVector",[22,46,30,62,58]);
as.getRange("A13:H13").merge();as.getRange("A13").values=[["状态转移规则（所有转移写入 event log：initiator, from, to, trigger, scope, reason, timestamp）"]];as.getRange("A13").format={fill:C.gold,font:{bold:true,color:C.navy}};
const transitions=[
 ["T0","session start","L0 Observe/L1 Infer","system","默认最小权限","无","不读取长期记忆直到项目/用户许可明确"],
 ["T1","证据积累且连续接受","最多上升一级","agent proposal + user acceptance","calibrated confidence高；commitment高；低风险可逆","≥2个独立成功episode；无近期repair","有冷却期，禁止一次跳到apply"],
 ["T2","用户明确请求某动作","仅授予请求scope所需权限","human","明确target/effect/scope","仍受结构风险与确认硬边界限制","请求不等于长期授权"],
 ["T3","候选接近或证据缺失","降至Infer/Suggest/Preview","system","ambiguity高或关键field unknown","显示差异/询问","不能用历史case填补授权"],
 ["T4","约束冲突/高blast radius","降至Preview/Ask","system","preserve冲突、拓扑或已承诺范围","显示影响并确认","无论intent confidence多高"],
 ["T5","undo/reject/repair","apply和select立即为0","human signal","结果被否定或需修复","诊断intent/target/frame/parameter/constraint/timing","暂停长期记忆写入"],
 ["T6","counter-drag/grab tool/reclaim","立即切到Human Control","human","用户直接反向输入或抢回工具","Agent停止、不争辩、不延迟","最高优先级，可跨级"],
 ["T7","用户忙碌/不可用","保持最后安全状态或降级","system","高连续操作、注意负荷高","延迟非关键主动建议","不可因无响应自动升级"],
 ["T8","新工具/OOD/模型冲突","降至Observe/Infer","system","解释链或能力边界不满足","标unknown并记录新case候选","禁止高置信伪装"],
 ["T9","确认成功并稳定","允许写episode；长期记忆按类型门槛","human outcome","accept + provenance完整","preference需跨episode；procedure需重复成功","commitment项目内保存且可reopen"]
];
const th=["ID","触发","目标状态/权限","发起者","判定依据","额外门槛","硬规则"];
table(as,14,th,transitions.map(r=>Object.fromEntries(th.map((h,i)=>[h,r[i]]))),"AuthorityTransitions",[10,38,32,24,58,56,52]);
as.getRange("A26:H26").merge();as.getRange("A26").values=[["运行时决策顺序（风险硬边界优先于概率）"]];as.getRange("A26").format={fill:C.teal,font:{bold:true,color:C.white}};
as.getRange("A27:H31").values=[
 ["1 Hard gates","privacy/permission","OOD/capability","constraint conflict","blast radius","commitment protection","human reclaim","任一失败即降级"],
 ["2 Belief","Top-k intent","reference frame","scope","commitment","ambiguity","evidence/counterevidence","只形成信念"],
 ["3 Utility","task gain","information gain","reversibility","interruption cost","agency cost","memory conflict","选最低必要权限"],
 ["4 Legibility","before/after","changed scope","preserved constraints","alternatives","confidence/source","undo path","无法说明则不apply"],
 ["5 Evaluation","switch count","control conflict","reclaim latency","surprise/violation","repair burden","agency/ownership","加任务性能和负荷"]
];as.getRange("A27:H31").format={wrapText:true,borders:{preset:"insideHorizontal",style:"thin",color:C.line}};
as.getRange("A33:H33").merge();as.getRange("A33").values=[["推荐实验条件：Human-initiated adjustable autonomy vs Agent-adaptive autonomy vs Mixed-initiative negotiated autonomy；按任务阶段与风险分层。"]];as.getRange("A33").format={fill:C.pale,font:{bold:true,color:C.ink},wrapText:true,borders:{preset:"outside",style:"medium",color:C.teal}};
as.getRange("A:A").format.columnWidth=18;as.getRange("B:H").format.columnWidth=25;

// 14. Intent Hypothesis Graph specification
const ihg=wb.worksheets.add("IntentGraph规范"); title(ihg,"Intent Hypothesis Graph：可执行中间表示规范","同时表示观察证据、用户目标假设、用户可能的世界/工具信念、竞争解释、结果和来源；unknown/other是必要状态，不是标注失败。","H");
const nodeRows=[
 ["ObservationEvent","event_id,time,actor,modality,target,raw_value","事实/日志","append-only","select/drag/pause/undo/speech/camera"],
 ["ContextState","scene_version,tool,mode,view,selection,design_stage","事实+推断","每事件更新并版本化","不能覆盖历史状态"],
 ["GoalHypothesis","goal_id,level,description,probability,status","推断","normalize; split/merge/supersede","project→stage→edit→operation→motor"],
 ["UserBeliefHypothesis","belief_id,scene/tool/frame belief,probability","推断","与goal联合更新","用户可能误解mode或局部轴"],
 ["Target","object_id,semantic_part,scope","事实+推断","允许多候选","object/part/region/scene"],
 ["DesiredEffect","semantic effect,visual/function delta","推断","由结果修订","区别于operation family"],
 ["Operation","family,parameters,trajectory","事实+推断","绑定工具和frame","translate/deform/generate/compare"],
 ["ReferenceFrame","world/local/view/surface_normal/semantic_axis","推断","竞争节点","不能只存最终Top-1"],
 ["Constraint","type,target,polarity,confidence,source","表达/推断","confirm后才升级为guardrail","preserve symmetry/topology/identity"],
 ["Evidence","evidence_id,time span,source,strength,visibility","事实+分析","不可脱离原始记录","支持或反驳具体hypothesis"],
 ["CommitmentState","exploratory/tentative/committed/unknown","推断+确认","与goal confidence独立更新","作用于权限策略"],
 ["Outcome","accept/modify/reject/undo/takeover/unresolved","事实+人工","episode结束写入","决定case role"],
 ["Repair","intent/target/frame/operation/parameter/scope/constraint/timing/authority","推断+确认","诊断后更新","undo不直接等于intent错误"],
 ["AuthoritySnapshot","authority vector,risk,reversibility,initiator","策略输出","每次转移记录","不能反向定义用户意图"],
 ["Provenance","source_type,model,prompt,coder,validation,version","元数据","append-only","控制检索和评估资格"]
];
const nh=["节点类型","必需字段","认识论状态","更新规则","例子/边界"];
table(ihg,4,nh,nodeRows.map(r=>Object.fromEntries(nh.map((h,i)=>[h,r[i]]))),"IHGNodes",[28,68,24,44,56]);
ihg.getRange("A21:H21").merge();ihg.getRange("A21").values=[["核心边类型"]];ihg.getRange("A21").format={fill:C.gold,font:{bold:true,color:C.navy}};
const edgeRows=[
 ["supports / contradicts","Evidence → Hypothesis","带weight和source","必须可追溯到时间段/日志"],
 ["refines / part_of","低层Goal → 高层Goal","形成层级","低层置信不自动传播为高层置信"],
 ["supersedes","新Hypothesis → 旧Hypothesis","意图修订","旧节点保留，不物理删除"],
 ["targets / affects","Goal或Operation → Target","定义scope","目标不确定时允许多条边"],
 ["uses_frame","Operation/Goal → ReferenceFrame","3D解释","多个frame竞争"],
 ["preserves / violates","Operation/Outcome → Constraint","安全检查","violates触发preview/confirm"],
 ["explained_by","Observation → Goal+UserBelief组合","逆向规划","允许不同belief解释同一动作"],
 ["causes / repairs","AgentAction/Outcome/Repair链","失败诊断","区分意图错与参数错"],
 ["retrieved_from","Hypothesis → MemoryCase","案例证据","不能变成authority边"],
 ["validated_by","Hypothesis → narration/recall/task/outcome","证据层级","教程表达与creator确认分开"]
];
const eh=["边","连接","属性","硬规则"];
table(ihg,22,eh,edgeRows.map(r=>Object.fromEntries(eh.map((h,i)=>[h,r[i]]))),"IHGEdges",[32,50,42,72]);
ihg.getRange("A34:H34").merge();ihg.getRange("A34").values=[["在线更新顺序"]];ihg.getRange("A34").format={fill:C.teal,font:{bold:true,color:C.white}};
ihg.getRange("A35:H41").values=[
 ["1 Ingest","追加ObservationEvent","更新ContextState版本","记录missing/visibility","不立即给唯一意图","","", ""],
 ["2 Propose","由规则/VLM/plan model提出Top-k Goal+UserBelief组合","加入unknown/other质量","生成target/effect/frame候选","","","", ""],
 ["3 Retrieve","检索support/near-miss/failed/alternative cases","只添加Evidence/retrieved_from","不复制历史authority","","","", ""],
 ["4 Update","posterior ∝ prior × event likelihood × plan fit × case evidence","constraint conflict单独记录","model mismatch提高unknown mass","","","", ""],
 ["5 Commitment","根据语言、保留、比较、撤销、阶段独立更新","不由goal posterior替代","","","","", ""],
 ["6 Policy","Authority State Machine读取posterior/unknown/commitment/risk/reversibility","输出observe/ask/suggest/preview/apply","","","","", ""],
 ["7 Outcome","写accept/reject/repair；修订或supersede假设","按provenance和确认度决定case retention","","","","", ""]
];ihg.getRange("A35:H41").format={wrapText:true,borders:{preset:"insideHorizontal",style:"thin",color:C.line}};
ihg.getRange("A35:H41").format.rowHeight=42;
ihg.getRange("A43:H45").merge();ihg.getRange("A43").values=[["最低运行时输出：{episode_id, context_version, hypotheses:[{goal, user_belief, target, effect, operation, frame, constraints, p, evidence_ids, counterevidence_ids}], unknown_mass, commitment, ambiguity, model_fit, authority_snapshot, provenance}.  评价时同时报告Top-k、校准、unknown detection、frame错误、约束漏报与权限严重错误。"]];ihg.getRange("A43:H45").format={fill:C.pale,wrapText:true,font:{color:C.ink,size:11},borders:{preset:"outside",style:"medium",color:C.teal}};
ihg.getRange("A:A").format.columnWidth=24;ihg.getRange("B:H").format.columnWidth=25;

// 15. Evidence quality and applicability audit
const qa=wb.worksheets.add("证据质量审计"); title(qa,"证据质量与 DC1 适用性审计","评分是用于综述决策的适用性 triage，不是研究偏差风险或效应强度评分。未完成 full-method appraisal 的文献不得单独支撑强因果声称。","O");
qa.getRange("A4:E9").values=[
  ["评分分量","量程","可审计定义","","权重"],
  ["证据访问","0–2","0=仅题录；1=摘要/扩展摘要/作者版；2=完整方法与结果已审查","",0.15],
  ["元数据完整","0–2","DOI/URL、年份、作者、出处等可追溯字段完整度","",0.10],
  ["DC1 直接性","1–3","3=直接解释3D操作/意图/参考系；2=支撑记忆/共创/权限/编码；1=背景","",0.30],
  ["可迁移性","1–3","3=可直接转为交互机制；2=需跨领域映射；1=窄场景","",0.20],
  ["实现效用","1–3","3=明确字段/策略/边界；2=提供原则；1=仅定位论点","",0.25]
];
for(let r=4;r<=9;r++) qa.getRange(`C${r}:D${r}`).merge();
qa.getRange("A4:E4").format={fill:C.teal,font:{bold:true,color:C.white}};
qa.getRange("A5:E9").format={wrapText:true,rowHeight:34,borders:{preset:"insideHorizontal",style:"thin",color:C.line}};
qa.getRange("E5:E9").format.numberFormat="0%";
qa.getRange("F4:O9").merge(); qa.getRange("F4").values=[["审计规则：① Study type 为题录/综合文本的暂定分类，必须由第二评审者核对；② Method appraisal=待完成时，不得将决策效用分解读为研究质量；③ 证据访问当前保守记为1，直到完整方法与结果已复核；④ 强因果、性能或人因声称需另行使用合适的risk-of-bias/checklist。"]];
qa.getRange("F4:O9").format={fill:C.pale,wrapText:true,verticalAlignment:"top",borders:{preset:"outside",style:"medium",color:C.gold},font:{color:C.ink,size:10}};
const qh=["ID","题名","年份","证据角色","研究类型（核验/暂定）","访问层级","访问0-2","元数据0-2","DC1直接1-3","可迁移1-3","实现效用1-3","方法评估","允许的声称","决策效用0-3","QA标记"];
const qr=data.included.map(p=>{
  const manual=manualAppraisals[p.include_id];
  const st=manual?.verifiedType || provisionalStudyType(p);
  const metadata=[p.title,p.year,p.authors,p.venue,(p.doi||p.url)].filter(Boolean).length>=5?2:1;
  const impl=(p.dc1_implication&&p.handoff_boundary)?3:(p.dc1_implication?2:1);
  const claim=manual?.allowedClaim || (st==="Theory / framework"?"机制/设计理据":st==="Review / synthesis"?"领域范围/概念地图":st==="Empirical evaluation"?"经验结果（方法复核后）":st==="Computational / technical"?"计算可行性/假设结构":"系统机制/设计实例");
  return {"ID":p.include_id,"题名":p.title,"年份":Number(p.year)||p.year,"证据角色":evidenceRole(p),"研究类型（核验/暂定）":st,"访问层级":manual?"Full method/structured abstract manually verified":"Abstract / extended abstract / author copy verified","访问0-2":manual?2:1,"元数据0-2":metadata,"DC1直接1-3":directness(p),"可迁移1-3":transferability(p),"实现效用1-3":impl,"方法评估":manual?manual.status:"Pending full-method appraisal","允许的声称":claim,"决策效用0-3":"","QA标记":manual?"Manual verification complete; independent second review still recommended":"Second-reviewer verification required"};
});
const qtab=table(qa,12,qh,qr,"EvidenceAudit",[9,48,9,28,25,32,11,12,13,13,14,25,32,15,30]);
qa.getRange(`N13`).formulas=[["=ROUND((G13/2*$E$5+H13/2*$E$6+I13/3*$E$7+J13/3*$E$8+K13/3*$E$9)*3,2)"]];
qa.getRange(`N13:N${qtab.endRow}`).fillDown(); qa.getRange(`N13:N${qtab.endRow}`).format.numberFormat="0.00";
qa.getRange(`B13:O${qtab.endRow}`).format.wrapText=true;
qa.getRange(`N13:N${qtab.endRow}`).conditionalFormats.add("colorScale",{colors:["#FADBD8","#FFF2CC","#DFF3E8"],thresholds:["min","50%","max"]});
qa.freezePanes.freezeRows(12);

// 16. Manual method verification for papers heuristically classified as empirical
const mv=wb.worksheets.add("方法核验"); title(mv,"经验证据方法核验","对自动规则曾标为 empirical 的 7 篇逐条复核。结果：5 篇是一手/混合经验证据，2 篇是综述；只有 I11/I86 适合支撑较强的接管机制声称。I22 原题名–DOI 组合经身份核验不匹配，已替换为可追溯的 Sentient Sketchbook 作者全文。","K");
const mvHeaders=["ID","题名","规则初判","核验类型","设计/样本","比较/分析","允许的 DC1 声称","主要发现","迁移限制","证据 URL","核验状态"];
const mvRows=Object.entries(manualAppraisals).map(([id,a])=>{
  const p=data.included.find(x=>x.include_id===id);
  return {"ID":id,"题名":p?.title||"","规则初判":a.heuristicType,"核验类型":a.verifiedType,"设计/样本":a.designSample,"比较/分析":a.comparisonAnalysis,"允许的 DC1 声称":a.allowedClaim,"主要发现":a.keyFinding,"迁移限制":a.transferLimit,"证据 URL":a.url,"核验状态":a.status};
});
const mvTab=table(mv,4,mvHeaders,mvRows,"MethodVerification",[9,46,24,30,52,48,48,56,54,48,34]);
mv.getRange(`B5:K${mvTab.endRow}`).format.wrapText=true;
mv.getRange(`A5:K${mvTab.endRow}`).format.rowHeight=78;
mv.getRange(`D5:D${mvTab.endRow}`).conditionalFormats.add("containsText",{text:"review",format:{fill:"#FFF2CC",font:{color:C.navy,bold:true}}});
mv.getRange(`K5:K${mvTab.endRow}`).conditionalFormats.add("containsText",{text:"verified",format:{fill:"#DFF3E8",font:{color:C.green,bold:true}}});
mv.freezePanes.freezeRows(4);

// 17. DC1 validation protocol
const vp=wb.worksheets.add("DC1验证协议"); title(vp,"DC1 验证协议：从教程 case 到真实共创","规模是可编辑的规划起点，不是已完成 power analysis 的最终样本量。教程用于建立操作—目标原型；真实任务与 stimulated recall 用于校验 latent intent 和接管边界。","H");
vp.getRange("A4:D13").values=[
  ["可编辑假设","值","单位","理由/计算"],
  ["内容层",6,"类","reference frame、selection/transform、shape/topology、constraints/assembly、appearance、exploration/repair"],
  ["每层教程视频",4,"条","保证每类不被单个创作者/工具完全主导"],
  ["教程视频总数","","条","'=内容层 × 每层视频"],
  ["预计 episode/视频",20,"个","先用6条pilot估计，后续替换为观察中位数"],
  ["预计 episode 总数","","个","'=视频数 × episode/视频"],
  ["pilot 视频",6,"条","每内容层1条，3人独立编码并修订codebook"],
  ["主语料双编比例",0.25,"比例","按内容层、罕见意图、低置信和权限风险分层抽样"],
  ["pilot三编 episodes","","个","'=pilot视频 × episode/视频"],
  ["主语料双编 episodes","","个","'=(总视频-pilot) × episode/视频 × 双编比例"]
];
vp.getRange("B7").formulas=[["=B5*B6"]]; vp.getRange("B9").formulas=[["=B7*B8"]]; vp.getRange("B12").formulas=[["=B10*B8"]]; vp.getRange("B13").formulas=[["=(B7-B10)*B8*B11"]];
vp.getRange("A4:D4").format={fill:C.teal,font:{bold:true,color:C.white}};vp.getRange("A5:D13").format={wrapText:true,rowHeight:30,borders:{preset:"insideHorizontal",style:"thin",color:C.line}};
vp.getRange("B11").format.numberFormat="0%";vp.getRange("A:A").format.columnWidth=28;vp.getRange("B:B").format.columnWidth=13;vp.getRange("C:C").format.columnWidth=12;vp.getRange("D:D").format.columnWidth=58;
vp.getRange("A15:H15").merge();vp.getRange("A15").values=[["分阶段证据链"]];vp.getRange("A15").format={fill:C.gold,font:{bold:true,color:C.navy}};
const phaseRows=[
  ["P0 Codebook pilot","6条教程，约120 episodes","3名人类编码员","VLM预分段+观察信号+Top-k意图+反证","3人独立编码；仲裁只在保留原始分歧后进行","boundary F1/segmentation similarity；分层α/κ；constraint recall","v1 codebook + boundary guide + VLM prompt"],
  ["P1 Tutorial case corpus","24条，6内容层×4","3名编码员；主语料25%双编","100%预标；标注observables/target/effect/frame/operation/alternatives","人审所有case；低信度、罕见、constraint/权限case优先复审","Top-k coverage；人机分歧；分层可靠性","case library v1（仅候选生成/检索）"],
  ["P2 Controlled ground truth","24–36名3D用户；每人2类任务","1 facilitator + 2 intent adjudicators","VLM标事件，不得覆盖task goal/creator report","constrained task提供目标真值；open task保留多意图","Top-k、NLL/Brier/ECE、unknown detection、frame error、constraint recall","intent benchmark + calibrated IHG"],
  ["P3 Think-aloud + recall","P2中12–16人子样本","1 interviewer + 2 coders","VLM只生成回放索引和冲突片段","任务后立即stimulated recall；区分当时意图与事后合理化","alternative-intent coverage；reason-source agreement；memory bias","creator-confirmed cases + ambiguity taxonomy"],
  ["P4 Mixed-initiative evaluation","30–36名3D用户，within-subject 3条件","Latin-square平衡；最终N由pilot effect/variance仿真决定","Agent运行IHG但实验记录完整posterior/authority trace","prompt-only vs fixed initiative vs adaptive IHG+authority","repair burden、commitment violation、severe authority error、agency/ownership、task time","DC1机制验证 + takeover boundary evidence"],
  ["P5 Longitudinal transfer","8–12人，2–4周","participants own projects","VLM只建议memory consolidation候选","参与者确认长期preference/skill；项目commitment默认不跨项目","stale-memory conflicts、reclaim latency、cross-project contamination","typed-memory retention/forgetting policy"]
];
const ph=["阶段","材料/样本","人员", "VLM职责","人类/真值职责","主要指标","最终产出"];
table(vp,16,ph,phaseRows.map(r=>Object.fromEntries(ph.map((h,i)=>[h,r[i]]))),"ValidationPhases",[24,42,34,48,52,48,42]);vp.getRange("A17:G22").format={wrapText:true,rowHeight:55};
vp.getRange("A24:H24").merge();vp.getRange("A24").values=[["教程内容覆盖：每层4条的目标是防止单一工具/创作者偏差，不是声称理论饱和。"]];vp.getRange("A24").format={fill:C.cyan,font:{bold:true,color:C.ink}};
const coverageRows=[
  ["Reference frame & navigation","orbit/pan/zoom/view alignment/local-world switch","view trajectory, cursor, gizmo, camera state","frame belief; epistemic vs pragmatic"],
  ["Selection & transform","object/part selection, move/rotate/scale, pivot","selection history, target granularity, modifiers","target; desired effect; scope; frame"],
  ["Shape & topology","extrude/inset/bevel/sculpt/remesh","mesh state, topology changes, brush/gizmo trajectory","operation family; topology risk; preserve"],
  ["Constraints & assembly","snap, align, symmetry, contact, mating","active constraints, contact graph, constraint violations","constraint; desired relation; blast radius"],
  ["Appearance & semantics","material, color, style, grouping/naming","property panels, object semantics, reference assets","semantic goal; preference vs commitment"],
  ["Exploration & repair","compare variants, undo/redo, counter-drag, reopen","pause, repeat, alternatives, accept/reject/repair","interaction function; commitment; repair cause"]
];
const ch=["内容层","必要任务","可观测信号", "IHG覆盖"];
table(vp,25,ch,coverageRows.map(r=>Object.fromEntries(ch.map((h,i)=>[h,r[i]]))),"TutorialCoverage",[30,58,55,52]);vp.getRange("A26:D31").format={wrapText:true,rowHeight:42};

// 17. Ablation and metric matrix
const ab=wb.worksheets.add("消融_指标矩阵"); title(ab,"DC1 消融与评价矩阵","把‘意图更准’拆成可归因的机制假设。每个模型同时报告准确性、校准、unknown/OOD、约束、修复与权限严重错误。","H");
const abRows=[
  ["A0","Action-only flat","motor event only; top-1 label","-","-","-","-","低层动作上限/最弱基线","macro-F1; top-k; ECE"],
  ["A1","+ Object/geometry","target/part/state/constraints","-","-","-","-","H1: 对象与几何显著改善target/effect","target F1; constraint recall"],
  ["A2","+ Temporal history","trajectory, pauses, repeats, undo","-","-","-","-","H1: 序列优于孤立事件","NLL/Brier; repair-cause F1"],
  ["A3","+ Goal hierarchy","project→stage→edit→motor","-","-","-","-","H1: 跨阶段/跨对象迁移更稳定","level-wise top-k; hierarchy consistency"],
  ["A4","+ User belief/frame","world/tool/frame hypotheses + unknown mass","-","-","-","-","IN17: 降低frame/OOD高置信错误","frame error; unknown AUROC/AUPRC; ECE"],
  ["A5","+ Typed memory","episodic/semantic/procedural + contrastive cases","support/near-miss/failure/alternative","-","-","-","H3: 检索改善校准但可能降低top-1置信","retrieval utility; stale conflict; calibration delta"],
  ["A6","+ Commitment/repair","intent content × commitment; diagnosed repair","typed+contrastive","-","-","-","H2/H4: 降低过早执行和修复负担","repair steps; commitment violations; reopen accuracy"],
  ["A7","+ Authority policy","full IHG evidence","typed+contrastive","adaptive breakpoint initiative","function-vector authority","yes","H4: 保持agency并减少严重越权","severe authority error; reclaim latency; agency/ownership"]
];
const ah=["条件","模型","意图表示/上下文","记忆","主动性","权限","执行","可归因假设","主要指标"];
table(ab,4,ah,abRows.map(r=>Object.fromEntries(ah.map((h,i)=>[h,r[i]]))),"AblationMatrix",[9,28,54,34,30,34,14,55,48]);ab.getRange("A5:I12").format={wrapText:true,rowHeight:52};
ab.getRange("A14:I14").merge();ab.getRange("A14").values=[["指标字典与严重性分层"]];ab.getRange("A14").format={fill:C.gold,font:{bold:true,color:C.navy}};
const metricRows=[
  ["语义正确","Level-wise macro-F1 / Top-k recall","goal/target/effect/operation/frame分层计算；不用一个整体准确率掩盖字段差异","Top-k与人类合理alternatives比较"],
  ["概率质量","NLL / Brier / ECE","ECE按风险和任务阶段分箱；保留unknown/other mass","top-1正确但过度自信仍为失败"],
  ["开集识别","Unknown AUROC + AUPRC","OOD tool/mode/frame、遮挡、关键日志缺失作为unknown测试集","AUPRC应对unknown稀少情形"],
  ["结构安全","Constraint recall / commitment violation","preserve constraint漏报与已接受结构被改动分开统计","commitment violation是高严重错误"],
  ["修复负担","Repair steps + time + cause accuracy","从错误Agent输出恢复到用户期望状态的步数/时间；诊断target/scope/frame/constraint/outcome","比接受率更能解释真实成本"],
  ["权限安全","Severe authority error / reclaim latency","Agent未授权select/apply/remember；或在undo/counter-drag/grab后未立即停止","严重错误应单独报告，不被平均准确率稀释"],
  ["人因结果","Agency / ownership / workload / trust calibration","agency和ownership不等于满意度；信任应评估appropriate reliance","结合行为指标与量表"],
  ["创造过程","Exploration breadth / reopen / solution diversity","不把多样性自动当成质量；与专家评分和创作者目标联合","test whether initiative narrows exploration"]
];
const metricHeaders=["类别","指标","计算/口径","解读边界"];
table(ab,15,metricHeaders,metricRows.map(r=>Object.fromEntries(metricHeaders.map((h,i)=>[h,r[i]]))),"MetricDictionary",[24,42,70,58]);ab.getRange("A16:D23").format={wrapText:true,rowHeight:48};
ab.getRange("A25:H27").merge();ab.getRange("A25").values=[["最小可发表比较：A0→A1 验证对象/几何语义；A2→A4 验证序列、层级与用户belief/frame；A4→A5 验证记忆对校准与负迁移的影响；A5→A6 验证commitment/repair；A6→A7 验证mixed-initiative与权限边界。不建议一次只报告A0 vs A7，因为无法归因改善来源。"]];ab.getRange("A25:H27").format={fill:C.pale,wrapText:true,font:{color:C.ink,size:11},borders:{preset:"outside",style:"medium",color:C.teal}};

// 18. Normalized intent-episode schema and field-level codebook
const cb=wb.worksheets.add("Episode编码字典"); title(cb,"Intent Episode 编码字典与 Case 库表结构","不用一行巨表强行塞入多个证据和竞争假设；用7个规范化表保留one-to-many证据、Top-k假设、约束、修复和provenance。","J");
const entityRows=[
  ["Episode","episode_id, source_id, start_ms, end_ms, context_version, task_stage, interaction_function, commitment, authority_snapshot_id, provenance_id, validation_status","episode_id","source_id; provenance_id","1 episode : many events/hypotheses/outcomes","IHG episode/context anchor"],
  ["ObservationEvent","event_id, episode_id, timestamp_ms, event_type, pointer_trajectory_ref, selected_before, selected_after, active_tool, tool_mode, modifiers, camera_state, scene_delta, system_feedback, visibility, missingness, evidence_strength, vlm_confidence, human_status","event_id","episode_id","many events : 1 episode","ObservationEvent/Evidence"],
  ["IntentHypothesis","hypothesis_id, episode_id, rank, goal_L0, goal_L1, goal_L2, goal_L3, target, desired_effect, operation_family, scope, reference_frame, user_world_belief, user_tool_belief, confidence, unknown_mass, model_fit, evidence_ids, counterevidence_ids, alternative_group, status","hypothesis_id","episode_id","many hypotheses : 1 episode","Goal/UserBelief/Target/Effect/Operation"],
  ["Constraint","constraint_id, hypothesis_id, constraint_type, object_relation, preserve_level, source, confidence, violation_risk","constraint_id","hypothesis_id","many constraints : 1 hypothesis","Constraint + preserves/violates"],
  ["OutcomeRepair","outcome_id, episode_id, agent_action, authority_level, user_response, outcome_state, repair_type, repair_cause, repair_latency_ms, commitment_violation, severe_authority_error, memory_retention_decision","outcome_id","episode_id","0..many outcomes : 1 episode","Outcome/Repair/AuthoritySnapshot"],
  ["Provenance","provenance_id, source_type, source_uri, creator_pseudonym, intent_source, coder_ids, vlm_model, vlm_prompt_hash, annotation_version, adjudication_status, consent_license","provenance_id","-","1 provenance : many episodes/cases","Provenance/validated_by"],
  ["MemoryCase","case_id, episode_id, case_role, similarity_score, reuse_utility, explanation_value, validation_tier, retention_scope, decay_expiry, negative_case_flag","case_id","episode_id","0..many cases : 1 episode","retrieved_from + retention governance"]
];
const entityHeaders=["表","精确 headers","主键","外键","基数", "IHG用途"];
table(cb,4,entityHeaders,entityRows.map(r=>Object.fromEntries(entityHeaders.map((h,i)=>[h,r[i]]))),"CaseSchema",[24,100,22,28,34,45]);cb.getRange("A5:F11").format={wrapText:true,rowHeight:64};
cb.getRange("A13:J13").merge();cb.getRange("A13").values=[["字段级 codebook：字段是可证伪的记录单元，不要将解释、观测和授权混成一个标签。"]];cb.getRange("A13").format={fill:C.gold,font:{bold:true,color:C.navy}};
const fieldRows=[
  ["Episode","episode_id","string","yes","stable UUID","system","generate only","verify linkage","uniqueness","episode anchor"],
  ["Episode","start_ms / end_ms","integer","yes","start < end; source timeline","video/log","propose boundary","correct boundary","tolerance F1 + segmentation similarity","temporal scope"],
  ["Episode","context_version","string","yes","scene/tool snapshot hash","system log","extract","verify mismatch","exact match / missing rate","ContextState"],
  ["Episode","task_stage","category","yes","orient/explore/construct/compare/refine/commit/repair","video+task","Top-k","confirm/alternatives","alpha/kappa","goal_L1"],
  ["Episode","interaction_function","category","yes","epistemic/pragmatic/communicative/repair/mixed/unknown","sequence","Top-k + evidence","confirm; preserve plurality","alpha + confusion","interaction function"],
  ["Episode","commitment","ordinal","yes","0 explore; 1 tentative; 2 preferred; 3 accepted; 4 locked; unknown","behavior+recall","estimate only","participant/coder confirm","weighted kappa / ordinal alpha","CommitmentState"],
  ["Episode","validation_status","category","yes","vlm_only/single_review/double_review/creator_confirmed/task_ground_truth/adjudicated","workflow","write initial","promote tier","audit counts","provenance gate"],
  ["ObservationEvent","event_type","category","yes","select/drag/rotate/scale/draw/menu/parameter/camera/undo/redo/pause/accept/reject/other","video/log","label","verify","alpha/kappa","ObservationEvent"],
  ["ObservationEvent","pointer_trajectory_ref","URI/array","conditional","screen/world coordinates + sampling rate","interaction log","extract if visible","verify alignment","coverage + trajectory error","observable evidence"],
  ["ObservationEvent","selected_before / selected_after","ID list","yes","object/part semantic IDs; empty allowed","scene log","extract","verify target identity","exact/Jaccard","target evidence"],
  ["ObservationEvent","active_tool / tool_mode","category","yes","tool taxonomy + unknown","UI/log","extract","verify hidden modes","alpha + missing rate","user_tool_belief evidence"],
  ["ObservationEvent","modifiers","set","no","keyboard/controller modifiers","UI/log","extract","verify","Jaccard","operation evidence"],
  ["ObservationEvent","camera_state","JSON","yes","view matrix/projection/visible region or unknown","scene log","extract","verify visibility","coverage + numeric tolerance","reference-frame evidence"],
  ["ObservationEvent","scene_delta","JSON","yes","changed objects/properties/topology/relations","scene diff","summarize","verify topology/relations","field recall","DesiredEffect/Outcome"],
  ["ObservationEvent","system_feedback","text/category","no","preview/error/snap/highlight/result","UI","extract","verify","alpha","feedback evidence"],
  ["ObservationEvent","visibility / missingness","category","yes","visible/occluded/offscreen/not_logged/unknown","video+log","flag","verify critical gaps","missing-rate + alpha","unknown mass"],
  ["ObservationEvent","evidence_strength","ordinal","yes","0 absent; 1 weak; 2 moderate; 3 strong","coding rule","suggest","final human rating","weighted kappa","Evidence weight"],
  ["ObservationEvent","vlm_confidence","number","yes","0..1; model-reported, not calibrated truth","VLM","write","do not overwrite","calibration later","review priority"],
  ["IntentHypothesis","rank","integer","yes","1..k; unknown/other is explicit candidate","model/coder","propose","re-rank/retain alternatives","Top-k coverage","alternatives"],
  ["IntentHypothesis","goal_L0..goal_L3","category/text","yes","project > stage > edit > motor; unknown at any level","task+narration+sequence","Top-k","confirm per level","level-wise alpha/Top-k","multi-level Goal"],
  ["IntentHypothesis","target","ID + semantic type","yes","object/part/relation/region/property","scene+behavior","propose","verify","exact/Jaccard","Target"],
  ["IntentHypothesis","desired_effect","predicate/state diff","yes","move_to/align_with/increase/replace/preserve/etc.","narration+delta","propose","confirm","semantic match + alpha","DesiredEffect"],
  ["IntentHypothesis","operation_family","category","yes","navigate/select/transform/model/constrain/assemble/style/compare/repair/other","behavior","propose","confirm","alpha/kappa","Operation"],
  ["IntentHypothesis","scope","JSON/category","yes","object/part/selection/group/global + affected IDs","scene+intent","propose","verify blast radius","Jaccard + recall","scope/authority"],
  ["IntentHypothesis","reference_frame","category","yes","screen/view/world/object/local/custom/unknown","trajectory+UI+recall","Top-k","confirm alternatives","alpha + frame error","ReferenceFrame"],
  ["IntentHypothesis","user_world_belief","predicate set","yes","belief about current geometry/relations/visibility","behavior+recall","hypothesize","participant/coder validate","coverage + disagreement","UserBeliefHypothesis"],
  ["IntentHypothesis","user_tool_belief","predicate set","yes","belief about active mode/mapping/modifier","behavior+recall","hypothesize","validate","coverage + disagreement","UserBeliefHypothesis"],
  ["IntentHypothesis","confidence","number","yes","posterior 0..1; hypotheses + unknown sum to 1","model","compute","calibration truth only","NLL/Brier/ECE","GoalHypothesis"],
  ["IntentHypothesis","unknown_mass","number","yes","0..1; missing/model mismatch/other","model+missingness","compute","audit false certainty","AUROC/AUPRC + ECE","unknown/other"],
  ["IntentHypothesis","model_fit","number/category","yes","good/partial/mismatch or 0..1","model diagnostics","compute","review mismatch","OOD detection","authority guard"],
  ["IntentHypothesis","evidence_ids / counterevidence_ids","ID lists","yes","must reference existing events/evidence","graph","link","verify completeness","orphan-link audit","supports/contradicts"],
  ["IntentHypothesis","alternative_group / status","string/category","yes","active/superseded/rejected/confirmed/unknown","workflow","initialize","adjudicate","coverage + audit","alternatives/supersedes"],
  ["Constraint","constraint_type","category","yes","symmetry/contact/alignment/topology/interface/style/semantic/custom","scene+intent","propose","confirm","label-wise alpha","Constraint"],
  ["Constraint","object_relation","predicate","yes","subject-relation-object + tolerance","scene","extract","verify","relation recall","preserve target"],
  ["Constraint","preserve_level","ordinal","yes","soft/preferred/hard/locked/unknown","recall+history","estimate","participant confirm","weighted kappa","commitment guard"],
  ["Constraint","source","category","yes","explicit/task/inferred/history/retrieved/unknown","provenance","infer","verify","source confusion","provenance"],
  ["Constraint","confidence / violation_risk","number","yes","0..1 each; separate belief from consequence","model","compute","audit high risk","calibration + recall","authority policy"],
  ["OutcomeRepair","agent_action / authority_level","JSON/category","yes","suggest/preview/select/apply/remember + scope","system log","extract","verify policy","exact + violation audit","AuthoritySnapshot"],
  ["OutcomeRepair","user_response","category","yes","accept/reject/modify/ignore/undo/counter_drag/grab_tool/clarify","log+video","label","verify","alpha","feedback"],
  ["OutcomeRepair","outcome_state","predicate set","yes","result + expected delta + side effects","scene diff","summarize","verify","state-diff accuracy","Outcome"],
  ["OutcomeRepair","repair_type / repair_cause","category","conditional","target/scope/operation/frame/constraint/magnitude/outcome/system/unknown","sequence+recall","propose","confirm","alpha + confusion","Repair"],
  ["OutcomeRepair","repair_latency_ms","integer","conditional","from detectable failure to restored/accepted state","log","calculate","verify endpoint","numeric agreement","repair burden"],
  ["OutcomeRepair","commitment_violation","boolean","yes","changed accepted/locked element without reopen","graph+log","flag","mandatory review","recall; zero-tolerance audit","severe boundary"],
  ["OutcomeRepair","severe_authority_error","boolean","yes","unauthorized select/apply/remember or failed immediate reclaim","authority log","flag","mandatory review","recall; zero-tolerance audit","takeover boundary"],
  ["OutcomeRepair","memory_retention_decision","category","yes","discard/ambiguity/success/failure/skill_candidate/preference_candidate/quarantine","governance","suggest","approve","audit","retain"],
  ["Provenance","source_type / source_uri","category/URI","yes","tutorial/controlled/open_task/recall/deployment + stable link","dataset","extract","verify","completeness","source tier"],
  ["Provenance","creator_pseudonym / coder_ids","ID lists","yes","pseudonymous; identity stored separately if consented","study system","never infer identity","verify","privacy audit","provenance"],
  ["Provenance","intent_source","category","yes","narration/task_ground_truth/think_aloud/stimulated_recall/inferred/outcome","workflow","tag","verify","source distribution","validated_by"],
  ["Provenance","vlm_model / vlm_prompt_hash","string","yes if VLM","immutable model/version/prompt hash","pipeline","write","audit","reproducibility","model provenance"],
  ["Provenance","annotation_version / adjudication_status","string/category","yes","raw_vlm/human_A/human_B/adjudicated + version","workflow","initialize","promote without deleting raw","version audit","provenance"],
  ["Provenance","consent_license","category","yes","research consent; redistribution/derivative restrictions","study/source","do not infer","verify before retention","privacy/license audit","case eligibility"],
  ["MemoryCase","case_role","category","yes","support/near_miss/failed_repair/alternative_intent/authority_boundary","retrieval curation","suggest","approve","role balance","contrastive retrieval"],
  ["MemoryCase","similarity_score","number","yes","0..1 retrieval similarity only","retriever","compute","audit","ranking metrics","retrieve"],
  ["MemoryCase","reuse_utility / explanation_value","number","yes","separate 0..1 judgments","outcome+human","estimate","confirm sampled cases","utility calibration","reuse/explain"],
  ["MemoryCase","validation_tier","category","yes","vlm_only/single/double/creator/task/adjudicated","provenance","copy","verify","tier audit","hard filter"],
  ["MemoryCase","retention_scope / decay_expiry","category/date","yes","session/project/user/global; expiry or no-decay reason","governance","suggest","approve","stale-case audit","typed memory"],
  ["MemoryCase","negative_case_flag","boolean","yes","true for failure/repair/unsafe near miss","outcome","flag","verify cause","negative recall","counterexample"]
];
const fieldHeaders=["表","字段","类型","必填","允许值/形式","证据源", "VLM职责","人类职责","可靠性/QA", "IHG/运行用途"];
const cbTab=table(cb,14,fieldHeaders,fieldRows.map(r=>Object.fromEntries(fieldHeaders.map((h,i)=>[h,r[i]]))),"EpisodeCodebook",[22,36,18,10,60,28,32,35,34,38]);cb.getRange(`A15:J${cbTab.endRow}`).format={wrapText:true,rowHeight:44};cb.freezePanes.freezeRows(14);

// 19. VLM-human annotation QA and review queue
const aq=wb.worksheets.add("标注QA流程"); title(aq,"VLM 预标注、人类复核与一致性计算","不必先开发完整标注平台：先用视频/日志脚本 + JSON/Excel + 版本控制跑pilot；只有当并发标注、帧级操作或安全隔离成为瓶颈时再做专用UI。","H");
aq.getRange("A4:C9").values=[
  ["复核分量","权重","定义（0–1）"],
  ["不确定性",0.30,"1 - max hypothesis probability，并受unknown mass校正"],
  ["新颖/OOD",0.15,"tool/mode/object/frame/model-fit 偏离"],
  ["约束风险",0.20,"constraint漏报或violation risk"],
  ["权限风险",0.25,"select/apply/remember权限与blast radius"],
  ["人机/人人分歧",0.10,"VLM与人或两名人类编码的结构化差异"]
];aq.getRange("A4:C4").format={fill:C.teal,font:{bold:true,color:C.white}};aq.getRange("A5:C9").format={wrapText:true,rowHeight:30,borders:{preset:"insideHorizontal",style:"thin",color:C.line}};aq.getRange("B5:B9").format.numberFormat="0%";
aq.getRange("E4:H9").merge();aq.getRange("E4").values=[["强制人审覆盖优先于综合分：① constraint_risk、authority_risk或disagreement 任一≥0.70；② model mismatch / unknown_mass高；③ 结构性、全局、拓扑或已承诺区域；④ undo/counter-drag/grab-tool；⑤ 罕见类、新工具、许可/同意不清。综合分用于其余case的队列排序，不是自动放行分。"]];aq.getRange("E4:H9").format={fill:C.pale,wrapText:true,verticalAlignment:"top",borders:{preset:"outside",style:"medium",color:C.gold}};
const reviewRows=[
  ["E_demo_001",0.65,0.10,0.20,0.10,0.20,"", ""],
  ["E_demo_002",0.30,0.25,0.80,0.40,0.35,"", ""],
  ["E_demo_003",0.45,0.70,0.30,0.85,0.25,"", ""],
  ["E_demo_004",0.20,0.15,0.10,0.10,0.05,"", ""],
  ["E_demo_005",0.55,0.45,0.55,0.50,0.75,"", ""]
];
const reviewHeaders=["episode_id","uncertainty","novelty_OOD","constraint_risk","authority_risk","disagreement","review_priority","routing"];
const rv=table(aq,12,reviewHeaders,reviewRows.map(r=>Object.fromEntries(reviewHeaders.map((h,i)=>[h,r[i]]))),"ReviewQueueExample",[22,16,16,18,18,17,18,34]);
aq.getRange("G13").formulas=[["=ROUND(B13*$B$5+C13*$B$6+D13*$B$7+E13*$B$8+F13*$B$9,3)"]];aq.getRange(`G13:G${rv.endRow}`).fillDown();
aq.getRange("H13").formulas=[["=IF(OR(D13>=0.7,E13>=0.7,F13>=0.7),\"Mandatory human review\",IF(G13>=0.55,\"Priority review\",\"Standard audit\"))"]];aq.getRange(`H13:H${rv.endRow}`).fillDown();
aq.getRange(`B13:G${rv.endRow}`).format.numberFormat="0.00";aq.getRange(`G13:G${rv.endRow}`).conditionalFormats.add("colorScale",{colors:["#DFF3E8","#FFF2CC","#FADBD8"],thresholds:["min","50%","max"]});
aq.getRange("A19:H19").merge();aq.getRange("A19").values=[["字段类型 → 一致性/质控指标（不强行用一个κ概括全部schema）"]];aq.getRange("A19").format={fill:C.gold,font:{bold:true,color:C.navy}};
const relRows=[
  ["时间边界","start/end ms","tolerance-window boundary F1 + segmentation similarity","pilot计算分布；不用完全相等","boundary disagreement 可独立于语义分歧"],
  ["单标类别","event/tool/stage/function","Krippendorff alpha or kappa + confusion matrix","α≥0.80可直接用；0.67–0.80仅暂定且需复核（作为本项目gate）","类别不平衡时必须同报prevalence"],
  ["多标签/集合","constraints/modifiers/targets","per-label alpha + Jaccard + micro/macro precision/recall","高风险constraint以recall为主","Jaccard不能代替罕见constraint漏报"],
  ["序数","commitment/evidence strength/preserve level","weighted kappa or ordinal alpha + adjacent-error rate","报告跨越2级以上的严重分歧","接管策略对大跨级更敏感"],
  ["候选集/分布","Top-k intent + alternatives","Top-k coverage + soft set overlap; distribution divergence","不把合理多解强制仲裁为唯一答案","保留coder A/B原始假设和理由"],
  ["概率","confidence/unknown mass/risk","Brier/NLL/ECE; AUROC/AUPRC for unknown","只有creator/task/outcome证据时才做校准","人类置信不是自动真值"],
  ["修复原因","repair type/cause","alpha/kappa + cause confusion + downstream repair burden","分开target/scope/operation/frame/constraint/magnitude/outcome","undo不等于目标反转"],
  ["权限安全","commitment violation/severe authority error","sensitivity/recall + exact event audit","零容忍安全队列；不用平均一致性稀释","false negative 比 false positive 更严重"]
];
const relHeaders=["字段结构","例子","主指标","计算/门槛","解读边界"];
table(aq,20,relHeaders,relRows.map(r=>Object.fromEntries(relHeaders.map((h,i)=>[h,r[i]]))),"ReliabilityRules",[28,40,52,58,55]);aq.getRange("A21:E28").format={wrapText:true,rowHeight:48};
aq.getRange("A30:H30").merge();aq.getRange("A30").values=[["最小可行工作流（无专用平台）"]];aq.getRange("A30").format={fill:C.teal,font:{bold:true,color:C.white}};
aq.getRange("A31:H37").values=[
  ["1 VLM pre-annotation","video/log → boundaries + observables + Top-k + counterevidence + missingness","raw_vlm版本只读","","","","", ""],
  ["2 Human A review","复核全部case；补target/effect/frame/constraints/alternatives","single_review","","","","", ""],
  ["3 Human B blind coding","pilot全量 + 主语料分层样本；不先看Human A结果","double_review","","","","", ""],
  ["4 Participant/task evidence","task ground truth / think-aloud / stimulated recall / outcome绑定到validated_by","creator/task tier","","","","", ""],
  ["5 Adjudication","先冻结A/B原始版本；仲裁边界或codebook问题；真实多解保留alternatives","adjudicated","","","","", ""],
  ["6 Case construction","只将达到对应validation tier的字段用于hard filter/评估","MemoryCase","","","","", ""],
  ["7 Retention governance","accept/reject/repair决定success/failure/ambiguity/quarantine；不自动升级authority","versioned case library","","","","", ""]
];aq.getRange("A31:H37").format={wrapText:true,rowHeight:38,borders:{preset:"insideHorizontal",style:"thin",color:C.line}};aq.getRange("B31:H37").merge(true);

// Compact verification and previews for every sheet.
for (const name of ["README_概览","PRISMA流程","检索日志",screenedSheetName,includedSheetName,"理论矩阵","信号_意图_记忆","接管边界","DC1设计要求","关键Insights","机制模型","案例检索规范","权限状态机","IntentGraph规范","证据质量审计","方法核验","DC1验证协议","消融_指标矩阵","Episode编码字典","标注QA流程"]) {
  const sheet=wb.worksheets.getItem(name);
  const used=sheet.getUsedRange();
  const previewRange=name==="IntentGraph规范"?"A1:H45":name==="证据质量审计"?"A1:O24":name==="方法核验"?"A1:K11":name==="DC1验证协议"?"A1:H31":name==="消融_指标矩阵"?"A1:I27":name==="Episode编码字典"?"A1:J30":name==="标注QA流程"?"A1:H37":((name==="案例检索规范"||name==="权限状态机")?"A1:H35":"A1:H22");
  const preview=await wb.render({sheetName:name,range:previewRange,scale:1,format:"png"});
  await fs.writeFile(`${previewDir}/${name}.png`,new Uint8Array(await preview.arrayBuffer()));
}
const check=await wb.inspect({kind:"table",range:"PRISMA流程!A4:C12",include:"values,formulas",tableMaxRows:15,tableMaxCols:5,maxChars:5000});
console.log(check.ndjson);
const qaCheck=await wb.inspect({kind:"table",range:"证据质量审计!A12:O18",include:"values,formulas",tableMaxRows:10,tableMaxCols:15,maxChars:8000});
console.log(qaCheck.ndjson);
const methodCheck=await wb.inspect({kind:"table",range:"方法核验!A4:K11",include:"values,formulas",tableMaxRows:10,tableMaxCols:11,maxChars:12000});
console.log(methodCheck.ndjson);
const protocolCheck=await wb.inspect({kind:"table",range:"DC1验证协议!A4:D13",include:"values,formulas",tableMaxRows:12,tableMaxCols:5,maxChars:6000});
console.log(protocolCheck.ndjson);
const reviewCheck=await wb.inspect({kind:"table",range:"标注QA流程!A12:H17",include:"values,formulas",tableMaxRows:10,tableMaxCols:8,maxChars:6000});
console.log(reviewCheck.ndjson);
const errors=await wb.inspect({kind:"match",searchTerm:"#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",options:{useRegex:true,maxResults:100},summary:"final formula error scan",maxChars:4000});
console.log(errors.ndjson);
const file=await SpreadsheetFile.exportXlsx(wb);
await file.save(`${outDir}/FlowStudio_DC1_PRISMA_Literature_Review_20260722_v11.xlsx`);
console.log(JSON.stringify({output:`${outDir}/FlowStudio_DC1_PRISMA_Literature_Review_20260722_v11.xlsx`,sheets:20,included:data.included.length,screened:data.screened.length,codebookFields:fieldRows.length,methodVerified:Object.keys(manualAppraisals).length}));
